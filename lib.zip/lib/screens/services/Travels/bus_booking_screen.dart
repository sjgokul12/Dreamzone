import 'package:flutter/material.dart';
import 'bus_list_screen.dart';
import '../../../services/bus_api_service.dart';

/// Travels Services List
final List<Map<String, dynamic>> travelsServicesList = [
  {
    'id': 'travel_irtc',
    'name': 'IRTC',
    'category': 'Travels',
    'asset_image': 'assets/IRCTC.png',
    'icon': 'train',
    'color': '#0284C7',
    'desc': 'Train ticket booking portal',
  },
  {
    'id': 'travel_flight',
    'name': 'Flight Booking',
    'category': 'Travels',
    'asset_image': 'assets/Flight Booking.png',
    'icon': 'flight',
    'color': '#2563EB',
    'desc': 'Domestic & international flight tickets',
  },
  {
    'id': 'travel_bus',
    'name': 'Bus booking',
    'category': 'Travels',
    'asset_image': 'assets/Bus booking.png',
    'icon': 'directions_bus',
    'color': '#EA580C',
    'desc': 'Online bus ticket reservation',
  },
];

/// Premium "Coming Soon" Modal Dialog matching User Theme
void showComingSoonDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (context) {
      return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
        elevation: 12,
        backgroundColor: Colors.white,
        child: Container(
          width: 340,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(28),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Orange Hourglass Icon Container
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF0E6),
                  shape: BoxShape.circle,
                ),
                child: const Center(
                  child: Icon(
                    Icons.hourglass_top_rounded,
                    color: Color(0xFFFF5500),
                    size: 40,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Title: Coming Soon
              const Text(
                'Coming Soon',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w900,
                  color: Color(0xFF003D99),
                  letterSpacing: 0.3,
                ),
              ),
              const SizedBox(height: 12),

              // Subtitle
              const Text(
                "We're crafting something amazing for you.\nStay tuned!",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w500,
                  color: Color(0xFF475569),
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 28),

              // OK Button
              SizedBox(
                width: 140,
                height: 46,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFF5500),
                    foregroundColor: Colors.white,
                    elevation: 4,
                    shadowColor: const Color(0xFFFF5500).withAlpha(100),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(24),
                    ),
                  ),
                  onPressed: () => Navigator.pop(context),
                  child: const Text(
                    'OK',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}

/// Standalone Responsive Bus Booking Screen
class BusBookingScreen extends StatefulWidget {
  const BusBookingScreen({super.key});

  @override
  State<BusBookingScreen> createState() => _BusBookingScreenState();
}

class _BusBookingScreenState extends State<BusBookingScreen> {
  static const Color primaryNavy = Color.fromARGB(255, 50, 199, 202);
  static const Color accentOrange = Color(0xFFFF5500);
  static const Color bgGrey = Color(0xFFF8FAFC);
  static const Color cardWhite = Color(0xFFFFFFFF);
  static const Color textDark = Color.fromARGB(255, 71, 93, 180);

  final TextEditingController _sourceController = TextEditingController();
  final TextEditingController _destController = TextEditingController();
  DateTime _journeyDate = DateTime.now().add(const Duration(days: 1));

  List<String> _stationList = [];
  bool _isLoadingStations = true;
  String? _stationError;

  @override
  void initState() {
    super.initState();
    _fetchStations();
  }

  Future<void> _fetchStations() async {
    try {
      final data = await BusApiService.getStations();
      if (data['stationList'] != null) {
        if (mounted) {
          setState(() {
            _stationList = (data['stationList'] as List)
                .map((s) => s['stationName'].toString())
                .toList();
            _isLoadingStations = false;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _stationError = 'Failed to load stations';
          _isLoadingStations = false;
        });
      }
    }
  }



  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _journeyDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 90)),
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: accentOrange,
              onPrimary: Colors.white,
              onSurface: textDark,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != _journeyDate) {
      setState(() {
        _journeyDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final width = mediaQuery.size.width;
    final isDesktop = width > 900;
    final isTablet = width > 600 && width <= 900;

    return Scaffold(
      backgroundColor: bgGrey,
      appBar: AppBar(
        backgroundColor: cardWhite,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new,
            color: primaryNavy,
            size: 18,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Bus Ticket Booking',
          style: TextStyle(
            color: textDark,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Dark Blue Header Search Card (Matching User Reference Image)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF142C44), primaryNavy, Color(0xFF1E4369)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: primaryNavy.withAlpha(80),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // DZI Travel Desk Badge
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withAlpha(35),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Colors.white.withAlpha(60),
                          width: 1,
                        ),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.directions_bus_filled_rounded,
                            color: Colors.white,
                            size: 16,
                          ),
                          SizedBox(width: 6),
                          Text(
                            'DZI Travel Desk',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Headline
                    const Text(
                      "India's Largest Bus Inventory 5000+ operators & 90,000+ Routes",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        height: 1.3,
                      ),
                    ),
                    const SizedBox(height: 8),

                    // Description Subtext
                    Text(
                      'Every Trip is Intelligent, transparent and designed for your comfort and safety with DZI bus Booking Service, which combines a vast network.',
                      style: TextStyle(
                        fontSize: 12.5,
                        color: Colors.white.withAlpha(210),
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Search Form Container
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white.withAlpha(15),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                          color: Colors.white.withAlpha(30),
                          width: 1,
                        ),
                      ),
                      child: isDesktop
                          ? Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Expanded(child: _buildSourceField()),
                                const SizedBox(width: 12),
                                Expanded(child: _buildDestField()),
                                const SizedBox(width: 12),
                                Expanded(child: _buildDateField(context)),
                                const SizedBox(width: 12),
                                _buildSearchButton(),
                              ],
                            )
                          : Column(
                              children: [
                                _buildSourceField(),
                                const SizedBox(height: 12),
                                _buildDestField(),
                                const SizedBox(height: 12),
                                Row(
                                  children: [
                                    Expanded(child: _buildDateField(context)),
                                    if (isTablet) ...[
                                      const SizedBox(width: 12),
                                      _buildSearchButton(),
                                    ],
                                  ],
                                ),
                                if (!isTablet) ...[
                                  const SizedBox(height: 16),
                                  SizedBox(
                                    width: double.infinity,
                                    child: _buildSearchButton(),
                                  ),
                                ],
                              ],
                            ),
                    ),
                  ],
                ),
              ),

              // Removed Available Buses list, now on separate screen
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSourceField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Source City',
          style: TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Autocomplete<String>(
            initialValue: TextEditingValue(text: _sourceController.text),
            optionsBuilder: (TextEditingValue textEditingValue) {
              if (textEditingValue.text.isEmpty) {
                return const Iterable<String>.empty();
              }
              return _stationList.where((String option) {
                return option.toLowerCase().contains(textEditingValue.text.toLowerCase());
              });
            },
            onSelected: (String selection) {
              _sourceController.text = selection;
            },
            optionsViewBuilder: (context, onSelected, options) {
              return Align(
                alignment: Alignment.topLeft,
                child: Material(
                  elevation: 8,
                  borderRadius: BorderRadius.circular(12),
                  clipBehavior: Clip.antiAlias,
                  color: Colors.white,
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxHeight: 200, maxWidth: MediaQuery.of(context).size.width - 64),
                    child: ListView.builder(
                      padding: EdgeInsets.zero,
                      shrinkWrap: true,
                      itemCount: options.length,
                      itemBuilder: (context, index) {
                        final option = options.elementAt(index);
                        return InkWell(
                          onTap: () => onSelected(option),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                            child: Text(
                              option,
                              style: const TextStyle(fontSize: 13, color: textDark),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              );
            },
            fieldViewBuilder: (context, controller, focusNode, onFieldSubmitted) {
              // Sync the local controller with the Autocomplete's internal controller when typing
              controller.addListener(() {
                _sourceController.text = controller.text;
              });
              return TextField(
                controller: controller,
                focusNode: focusNode,
                style: const TextStyle(fontSize: 13, color: textDark),
                decoration: const InputDecoration(
                  hintText: 'Search Source City',
                  prefixIcon: Icon(
                    Icons.location_on_outlined,
                    color: accentOrange,
                    size: 18,
                  ),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 12,
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildDestField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Destination City',
          style: TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Autocomplete<String>(
            initialValue: TextEditingValue(text: _destController.text),
            optionsBuilder: (TextEditingValue textEditingValue) {
              if (textEditingValue.text.isEmpty) {
                return const Iterable<String>.empty();
              }
              return _stationList.where((String option) {
                return option.toLowerCase().contains(textEditingValue.text.toLowerCase());
              });
            },
            onSelected: (String selection) {
              _destController.text = selection;
            },
            optionsViewBuilder: (context, onSelected, options) {
              return Align(
                alignment: Alignment.topLeft,
                child: Material(
                  elevation: 8,
                  borderRadius: BorderRadius.circular(12),
                  clipBehavior: Clip.antiAlias,
                  color: Colors.white,
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxHeight: 200, maxWidth: MediaQuery.of(context).size.width - 64),
                    child: ListView.builder(
                      padding: EdgeInsets.zero,
                      shrinkWrap: true,
                      itemCount: options.length,
                      itemBuilder: (context, index) {
                        final option = options.elementAt(index);
                        return InkWell(
                          onTap: () => onSelected(option),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                            child: Text(
                              option,
                              style: const TextStyle(fontSize: 13, color: textDark),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              );
            },
            fieldViewBuilder: (context, controller, focusNode, onFieldSubmitted) {
              controller.addListener(() {
                _destController.text = controller.text;
              });
              return TextField(
                controller: controller,
                focusNode: focusNode,
                style: const TextStyle(fontSize: 13, color: textDark),
                decoration: const InputDecoration(
                  hintText: 'Search Destination City',
                  prefixIcon: Icon(
                    Icons.near_me_outlined,
                    color: accentOrange,
                    size: 18,
                  ),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 12,
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildDateField(BuildContext context) {
    final dateStr =
        '${_journeyDate.month.toString().padLeft(2, '0')}/${_journeyDate.day.toString().padLeft(2, '0')}/${_journeyDate.year}';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Journey Date',
          style: TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 6),
        GestureDetector(
          onTap: () => _selectDate(context),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  dateStr,
                  style: const TextStyle(fontSize: 13, color: textDark),
                ),
                const Icon(
                  Icons.calendar_today_outlined,
                  color: Colors.grey,
                  size: 16,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSearchButton() {
    return SizedBox(
      height: 44,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: accentOrange,
          foregroundColor: Colors.white,
          elevation: 4,
          shadowColor: accentOrange.withAlpha(100),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 24),
        ),
        onPressed: () {
          final dateStr = '${_journeyDate.year}-${_journeyDate.month.toString().padLeft(2, '0')}-${_journeyDate.day.toString().padLeft(2, '0')}';
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => BusListScreen(
                sourceCity: _sourceController.text,
                destinationCity: _destController.text,
                doj: dateStr,
              ),
            ),
          );
        },
        child: const Text(
          'Search Buses',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
