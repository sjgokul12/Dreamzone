import 'package:flutter/material.dart';
import '../../../services/bus_api_service.dart';
import 'bus_seat_layout_screen.dart';

class BusListScreen extends StatefulWidget {
  final String sourceCity;
  final String destinationCity;
  final String doj;

  const BusListScreen({
    super.key,
    required this.sourceCity,
    required this.destinationCity,
    required this.doj,
  });

  @override
  State<BusListScreen> createState() => _BusListScreenState();
}

class _BusListScreenState extends State<BusListScreen> {
  bool _isLoading = true;
  List<dynamic> _buses = [];

  @override
  void initState() {
    super.initState();
    _fetchBuses();
  }

  Future<void> _fetchBuses() async {
    try {
      final data = await BusApiService.getAvailableBuses(
        sourceCity: widget.sourceCity,
        destinationCity: widget.destinationCity,
        doj: widget.doj,
      );
      setState(() {
        _buses = data['apiAvailableBuses'] ?? [];
        _isLoading = false;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${widget.sourceCity} to ${widget.destinationCity}', style: const TextStyle(color: Colors.black87, fontSize: 16)),
            Text(widget.doj, style: const TextStyle(color: Colors.grey, fontSize: 12)),
          ],
        ),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFFFF5500)))
          : _buses.isEmpty
              ? const Center(child: Text('No buses found for this route.'))
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _buses.length,
                  itemBuilder: (context, index) {
                    final bus = _buses[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(
                                    bus['operatorName'] ?? 'Unknown Operator',
                                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(color: Colors.green[50], borderRadius: BorderRadius.circular(8)),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.star, size: 14, color: Colors.green),
                                      const SizedBox(width: 4),
                                      Text('4.5', style: TextStyle(color: Colors.green[700], fontWeight: FontWeight.bold)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(bus['busType'] ?? '', style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                            const SizedBox(height: 16),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(bus['departureTime'] ?? '', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                                      Text(widget.sourceCity, style: const TextStyle(fontSize: 11, color: Colors.grey), overflow: TextOverflow.ellipsis),
                                    ],
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Column(
                                    children: [
                                      Text('${(bus['durationInMins'] ?? 0) ~/ 60}h ${(bus['durationInMins'] ?? 0) % 60}m', style: const TextStyle(fontSize: 11, color: Color(0xFFFF5500))),
                                      const Icon(Icons.arrow_forward, color: Color(0xFFFF5500), size: 16),
                                    ],
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(bus['arrivalTime'] ?? '', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                                      Text(widget.destinationCity, style: const TextStyle(fontSize: 11, color: Colors.grey), overflow: TextOverflow.ellipsis),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  flex: 3,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text('₹${(bus['fare'] ?? '0').toString().split(',').first}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF142C44))),
                                      const SizedBox(height: 4),
                                      SizedBox(
                                        height: 32,
                                        width: double.infinity,
                                        child: ElevatedButton(
                                          onPressed: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => BusSeatLayoutScreen(
                                                busDetails: bus,
                                                sourceCity: widget.sourceCity,
                                                destinationCity: widget.destinationCity,
                                                doj: widget.doj,
                                              ),
                                            ),
                                          );
                                        },
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: const Color(0xFFFF5500),
                                            foregroundColor: Colors.white,
                                            padding: const EdgeInsets.symmetric(horizontal: 4),
                                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                          ),
                                          child: const FittedBox(child: Text('Select Seats', style: TextStyle(fontSize: 12))),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            const Divider(height: 24),
                            Row(
                              children: [
                                const Icon(Icons.chair_alt, size: 16, color: Colors.grey),
                                const SizedBox(width: 4),
                                Text('${bus['availableSeats']} Seats Left', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                                const Spacer(),
                                if (bus['busAmenities'] != null)
                                  ...((bus['busAmenities'] as List).take(3).map((a) => Padding(
                                        padding: const EdgeInsets.only(left: 8),
                                        child: Text(a.toString(), style: const TextStyle(fontSize: 10, color: Colors.grey)),
                                      ))),
                              ],
                            )
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
