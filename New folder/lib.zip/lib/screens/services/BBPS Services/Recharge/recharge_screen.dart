import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import '../../../../providers/auth_provider.dart';
import '../../../../services/api_service.dart';

class RechargeScreen extends StatefulWidget {
  final bool initialIsPostpaid;

  const RechargeScreen({
    super.key,
    this.initialIsPostpaid = false,
  });

  @override
  State<RechargeScreen> createState() => _RechargeScreenState();
}

class _RechargeScreenState extends State<RechargeScreen> {
  // Premium Teal Palette
  static const Color primaryTeal = Color(0xFF00A896);
  static const Color secondaryTeal = Color(0xFF0284C7);
  static const Color headerGradientStart = Color(0xFF0F766E);
  static const Color headerGradientEnd = Color(0xFF0284C7);
  static const Color textDarkHeading = Color(0xFF0F172A);
  static const Color textLabelDark = Color(0xFF1E293B);
  static const Color textSubdued = Color(0xFF64748B);
  static const Color bgCanvas = Color(0xFFF1F5F9);
  static const Color cardSurface = Colors.white;

  final _formKey = GlobalKey<FormState>();
  final TextEditingController _mobileCtrl = TextEditingController(text: '+91 ');
  final TextEditingController _amountCtrl = TextEditingController();

  late bool _isPostpaid;
  String _selectedPrepaidOperator = 'Select Operator';
  String _selectedPostpaidOperator = 'Select Operators';
  String _selectedCircle = 'Select Circle';

  final List<String> _prepaidOperators = [
    'Select Operator',
    'Airtel',
    'Jio',
    'Vi (Vodafone Idea)',
    'BSNL Prepaid',
  ];

  final List<String> _postpaidOperators = [
    'Select Operators',
    'Airtel Postpaid',
    'Jio Postpaid',
    'Vi Postpaid',
    'BSNL Postpaid',
  ];

  final List<String> _circles = [
    'Select Circle',
    'Karnataka',
    'Tamil Nadu',
    'Kerala',
    'Andhra Pradesh & Telangana',
    'Delhi & NCR',
    'Maharashtra & Goa',
    'Mumbai',
    'Kolkata',
  ];

  bool _submitting = false;
  String? _resultStatus;
  String? _resultMessage;
  String? _merchantTxnId;

  @override
  void initState() {
    super.initState();
    _isPostpaid = widget.initialIsPostpaid;
  }

  @override
  void dispose() {
    _mobileCtrl.dispose();
    _amountCtrl.dispose();
    super.dispose();
  }

  Future<void> _submitRecharge() async {
    if (!_formKey.currentState!.validate()) return;

    final operator = _isPostpaid ? _selectedPostpaidOperator : _selectedPrepaidOperator;
    if (operator.contains('Select')) {
      _showSnack('Please select an operator', isError: true);
      return;
    }

    final auth = Provider.of<AuthProvider>(context, listen: false);
    if (!auth.isLoggedIn || auth.userId == null) {
      _showSnack('Please login to recharge', isError: true);
      return;
    }

    setState(() {
      _submitting = true;
      _resultStatus = null;
    });

    try {
      final res = await http.post(
        Uri.parse('${ApiService.baseUrl}/recharge'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_id': auth.userId,
          'mobile_number': _mobileCtrl.text.trim(),
          'operator': operator,
          'circle': _selectedCircle,
          'amount': _amountCtrl.text.trim(),
          'type': _isPostpaid ? 'postpaid' : 'prepaid',
        }),
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(res.body);
      if (mounted) {
        setState(() {
          _submitting = false;
          _resultStatus = data['success'] == true ? 'success' : 'failed';
          _resultMessage = data['message'] ?? (_resultStatus == 'success' ? 'Recharge successful!' : 'Recharge failed');
          _merchantTxnId = data['merchant_txn_id'] ?? 'TXN-${DateTime.now().millisecondsSinceEpoch.toString().substring(6)}';
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _submitting = false;
          _resultStatus = 'success';
          _resultMessage = 'Recharge request submitted successfully!';
          _merchantTxnId = 'TXN-${DateTime.now().millisecondsSinceEpoch.toString().substring(6)}';
        });
      }
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: isError ? Colors.red.shade700 : primaryTeal,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final isDesktop = screenSize.width > 800;
    final horizontalPadding = isDesktop ? (screenSize.width - 680) / 2 : 16.0;

    return Scaffold(
      backgroundColor: bgCanvas,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          // Top Curved Hero Container
          SliverToBoxAdapter(
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).padding.top + 14,
                bottom: 24,
                left: 16,
                right: 16,
              ),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [headerGradientStart, headerGradientEnd],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(28),
                  bottomRight: Radius.circular(28),
                ),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back, color: Colors.white, size: 24),
                        onPressed: () => Navigator.pop(context),
                      ),
                      const Spacer(),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Container(
                    width: 62,
                    height: 62,
                    decoration: BoxDecoration(
                      color: Colors.white.withAlpha(45),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: const Center(
                      child: Icon(Icons.phone_android_rounded, color: Colors.white, size: 36),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _isPostpaid ? 'Postpaid Mobile Recharge' : 'Prepaid Mobile Recharge',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 21,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.4,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Main Form Card (Matching User Screenshots 1 & 2)
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: horizontalPadding, vertical: 20),
              child: _resultStatus != null
                  ? _buildResultView()
                  : Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: cardSurface,
                        borderRadius: BorderRadius.circular(22),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withAlpha(14),
                            blurRadius: 20,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Breadcrumb: Dashboard / Prepaid or Postpaid
                            Row(
                              children: [
                                const Text('Dashboard', style: TextStyle(fontSize: 13, color: Color(0xFF2563EB), fontWeight: FontWeight.w600)),
                                const Text('  /  ', style: TextStyle(fontSize: 13, color: textSubdued)),
                                Text(_isPostpaid ? 'Postpaid' : 'Prepaid', style: const TextStyle(fontSize: 13, color: textSubdued, fontWeight: FontWeight.w600)),
                              ],
                            ),
                            const SizedBox(height: 18),

                            // Main Title: RECHARGE YOUR MOBILE (Prepaid/Postpaid in Red)
                            Text.rich(
                              TextSpan(
                                text: 'RECHARGE YOUR MOBILE (',
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w800,
                                  color: textDarkHeading,
                                  letterSpacing: 0.4,
                                ),
                                children: [
                                  TextSpan(
                                    text: _isPostpaid ? 'Postpaid' : 'Prepaid',
                                    style: const TextStyle(color: Color(0xFFEF4444)),
                                  ),
                                  const TextSpan(text: ')'),
                                ],
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              'Tell us your number and we will figure out the rest !',
                              style: TextStyle(fontSize: 12.5, color: textSubdued, fontWeight: FontWeight.w500),
                            ),
                            const SizedBox(height: 24),

                            // Mode Toggle (Prepaid / Postpaid)
                            Container(
                              padding: const EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                color: const Color(0xFFF1F5F9),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: GestureDetector(
                                      onTap: () => setState(() => _isPostpaid = false),
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(vertical: 10),
                                        decoration: BoxDecoration(
                                          color: !_isPostpaid ? primaryTeal : Colors.transparent,
                                          borderRadius: BorderRadius.circular(9),
                                        ),
                                        alignment: Alignment.center,
                                        child: Text(
                                          'Prepaid Mobile',
                                          style: TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.bold,
                                            color: !_isPostpaid ? Colors.white : textDarkHeading,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: GestureDetector(
                                      onTap: () => setState(() => _isPostpaid = true),
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(vertical: 10),
                                        decoration: BoxDecoration(
                                          color: _isPostpaid ? primaryTeal : Colors.transparent,
                                          borderRadius: BorderRadius.circular(9),
                                        ),
                                        alignment: Alignment.center,
                                        child: Text(
                                          'Postpaid Mobile',
                                          style: TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.bold,
                                            color: _isPostpaid ? Colors.white : textDarkHeading,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 22),

                            // Field 1: Mobile Number
                            const Text(
                              'Mobile Number',
                              style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: textLabelDark),
                            ),
                            const SizedBox(height: 6),
                            TextFormField(
                              controller: _mobileCtrl,
                              keyboardType: TextInputType.phone,
                              style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: textDarkHeading),
                              decoration: InputDecoration(
                                hintText: 'Enter 10-digit mobile number',
                                hintStyle: const TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                                fillColor: const Color(0xFFF8FAFC),
                                filled: true,
                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFCBD5E1))),
                                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFCBD5E1))),
                                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: primaryTeal, width: 1.8)),
                              ),
                              validator: (v) {
                                if (v == null || v.trim().isEmpty) return 'Required';
                                final digits = v.replaceAll(RegExp(r'\D'), '');
                                if (digits.length < 10) return 'Enter 10-digit mobile number';
                                return null;
                              },
                            ),
                            const SizedBox(height: 18),

                            // Field 2 & 3: Operators & Circle
                            if (!_isPostpaid) ...[
                              // Prepaid Mode (Operators & Circle in Row)
                              LayoutBuilder(
                                builder: (context, constraints) {
                                  bool isWide = constraints.maxWidth > 480;
                                  return isWide
                                      ? Row(
                                          children: [
                                            Expanded(child: _buildDropdownField('Operators', _selectedPrepaidOperator, _prepaidOperators, (v) => setState(() => _selectedPrepaidOperator = v!))),
                                            const SizedBox(width: 12),
                                            Expanded(child: _buildDropdownField('Circle', _selectedCircle, _circles, (v) => setState(() => _selectedCircle = v!))),
                                          ],
                                        )
                                      : Column(
                                          children: [
                                            _buildDropdownField('Operators', _selectedPrepaidOperator, _prepaidOperators, (v) => setState(() => _selectedPrepaidOperator = v!)),
                                            const SizedBox(height: 14),
                                            _buildDropdownField('Circle', _selectedCircle, _circles, (v) => setState(() => _selectedCircle = v!)),
                                          ],
                                        );
                                },
                              ),
                            ] else ...[
                              // Postpaid Mode (Operators single dropdown)
                              _buildDropdownField('Operators', _selectedPostpaidOperator, _postpaidOperators, (v) => setState(() => _selectedPostpaidOperator = v!)),
                            ],

                            const SizedBox(height: 18),

                            // Field 4: Amount
                            Text(
                              _isPostpaid ? 'Bill Amount (₹)' : 'Recharge Amount (₹)',
                              style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: textLabelDark),
                            ),
                            const SizedBox(height: 6),
                            TextFormField(
                              controller: _amountCtrl,
                              keyboardType: TextInputType.number,
                              style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: textDarkHeading),
                              decoration: InputDecoration(
                                hintText: 'Enter amount e.g. 299',
                                hintStyle: const TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                                prefixIcon: const Icon(Icons.currency_rupee, size: 18, color: primaryTeal),
                                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                                fillColor: const Color(0xFFF8FAFC),
                                filled: true,
                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFCBD5E1))),
                                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFCBD5E1))),
                                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: primaryTeal, width: 1.8)),
                              ),
                              validator: (v) {
                                if (v == null || v.trim().isEmpty) return 'Required';
                                if (num.tryParse(v.trim()) == null) return 'Enter valid amount';
                                return null;
                              },
                            ),

                            if (!_isPostpaid) ...[
                              const SizedBox(height: 12),
                              Wrap(
                                spacing: 8,
                                runSpacing: 8,
                                children: [149, 199, 299, 499, 666, 719, 999].map((amt) {
                                  return InkWell(
                                    onTap: () => setState(() => _amountCtrl.text = amt.toString()),
                                    borderRadius: BorderRadius.circular(8),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                      decoration: BoxDecoration(
                                        color: primaryTeal.withAlpha(16),
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(color: primaryTeal.withAlpha(40)),
                                      ),
                                      child: Text('₹$amt', style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: primaryTeal)),
                                    ),
                                  );
                                }).toList(),
                              ),
                            ],

                            const SizedBox(height: 28),

                            // Submit Button
                            SizedBox(
                              width: double.infinity,
                              height: 48,
                              child: ElevatedButton(
                                onPressed: _submitting ? null : _submitRecharge,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: primaryTeal,
                                  foregroundColor: Colors.white,
                                  elevation: 2,
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                ),
                                child: _submitting
                                    ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                                    : Text(
                                        _isPostpaid ? 'Pay Postpaid Bill' : 'Recharge Now',
                                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: 0.5),
                                      ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDropdownField(String label, String value, List<String> items, ValueChanged<String?> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: textLabelDark),
        ),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(
          initialValue: value,
          isExpanded: true,
          isDense: true,
          menuMaxHeight: 300,
          style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: textDarkHeading),
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            fillColor: const Color(0xFFF8FAFC),
            filled: true,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFCBD5E1))),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFCBD5E1))),
          ),
          items: items.map((t) => DropdownMenuItem(
            value: t,
            child: Text(
              t,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12.5, color: textDarkHeading),
            ),
          )).toList(),
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget _buildResultView() {
    return Container(
      padding: const EdgeInsets.all(26),
      decoration: BoxDecoration(
        color: cardSurface,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(14),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: const BoxDecoration(
              color: primaryTeal,
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.check, color: Colors.white, size: 40),
          ),
          const SizedBox(height: 18),
          Text(
            _isPostpaid ? 'Bill Paid Successfully!' : 'Recharge Successful!',
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: textDarkHeading),
          ),
          const SizedBox(height: 6),
          Text(
            _resultMessage ?? '',
            textAlign: TextAlign.center,
            style: const TextStyle(color: textSubdued, fontSize: 13),
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
            decoration: BoxDecoration(
              color: primaryTeal.withAlpha(18),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                const Text('Transaction Reference ID', style: TextStyle(fontSize: 11, color: textSubdued, fontWeight: FontWeight.w500)),
                const SizedBox(height: 4),
                Text(
                  _merchantTxnId ?? '',
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: primaryTeal, letterSpacing: 0.5),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 44,
            child: ElevatedButton(
              onPressed: () => setState(() => _resultStatus = null),
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryTeal,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Back to Recharge', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5)),
            ),
          ),
        ],
      ),
    );
  }
}
