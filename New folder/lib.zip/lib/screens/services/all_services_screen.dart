import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../services/api_service.dart';
import 'service_detail_screen.dart';
import 'Home Product/Aadhaar/aadhaar_service_screen.dart';
import 'Home Product/Pan/pan_service_screen.dart';
import 'Home Product/Gst/gst_service_screen.dart';
import 'Home Product/Voter Id/voter_id_service_screen.dart';
import 'BBPS Services/Recharge/recharge_screen.dart';
import 'BBPS Services/Landline/Landline.dart';
import 'BBPS Services/DTH/DTH.dart';
import 'BBPS Services/Electricity/Electricity.dart';
import 'BBPS Services/Piped Gas Bill/Piped Gas Bill.dart';
import 'BBPS Services/Gas Cylinder/Gas Cylinder.dart';
import 'BBPS Services/Water/Water.dart';
import 'BBPS Services/Education/Education.dart';
import 'BBPS Services/Loan Payment/Loan Payment.dart';
import 'BBPS Services/Municipal Taxes/Municipal Taxes.dart';
import 'BBPS Services/Housing Society/Housing Society.dart';
import 'BBPS Services/Metro Card/Metro Card.dart';
import 'BBPS Services/Broadband/Broadband.dart';
import 'BBPS Services/Insurance/Insurance.dart';
import 'BBPS Services/Fastag/Fastag.dart';
import 'Home Product/Fastag/fastag_purchase_screen.dart';
import 'Home Product/Dsc/dsc_service_screen.dart';
import 'Home Product/Msme/msme_service_screen.dart';
import 'Home Product/Fssai/fssai_service_screen.dart';
import 'Home Product/Passport/passport_service_screen.dart';
import 'Payment Services/Money Transfer/Money Transfer.dart';
import 'E Government Services/e_government_screen.dart';
import 'Travels/bus_booking_screen.dart';

class AllServicesScreen extends StatefulWidget {
  final List<Map<String, dynamic>> services;
  final bool isGuest;
  const AllServicesScreen({
    super.key,
    required this.services,
    this.isGuest = false,
  });

  @override
  State<AllServicesScreen> createState() => _AllServicesScreenState();
}

class _AllServicesScreenState extends State<AllServicesScreen> {
  final ApiService _api = ApiService();
  String _searchQuery = '';
  String _selectedCategory = 'Home Product';
  bool _loadingSections = false;

  static const Color primaryOrange = Color(0xFF00A896);
  static const Color accentOrange = Color(0xFFFF6B00);
  static const Color bgCream = Color(0xFFF4FBF7);
  static const Color cardWhite = Color(0xFFFFFFFF);
  static const Color textDark = Color(0xFF1A0D08);

  Color _parseColor(dynamic c) {
    if (c == null) return primaryOrange;
    if (c is int) return Color(c);
    if (c is String) {
      String s = c.trim();
      if (s.startsWith('0x') || s.startsWith('0X')) {
        final v = int.tryParse(s);
        if (v != null) return Color(v);
      }
      if (s.startsWith('#')) {
        final v = int.tryParse('0xFF${s.substring(1)}');
        if (v != null) return Color(v);
      }
    }
    return primaryOrange;
  }

  IconData _parseIcon(dynamic i) {
    if (i == null) return Icons.assured_workload;
    switch ((i ?? '').toString().trim()) {
      case 'dth':
      case 'tv':
        return Icons.tv_rounded;
      case 'landline':
      case 'phone_in_talk':
        return Icons.phone_in_talk;
      case 'account_balance':
        return Icons.account_balance;
      case 'payments':
        return Icons.payments;
      case 'phone_android':
        return Icons.phone_android;
      case 'flight_takeoff':
        return Icons.flight_takeoff;
      case 'health_and_safety':
        return Icons.health_and_safety;
      case 'credit_card':
        return Icons.credit_card;
      case 'receipt_long':
        return Icons.receipt_long;
      case 'description':
        return Icons.description;
      case 'fingerprint':
        return Icons.fingerprint;
      case 'account_balance_wallet':
        return Icons.account_balance_wallet;
      case 'point_of_sale':
        return Icons.point_of_sale;
      case 'receipt':
        return Icons.receipt;
      default:
        return Icons.assured_workload;
    }
  }

  String _imageUrl(String? relativePath) {
    if (relativePath == null || relativePath.trim().isEmpty) return '';
    String path = relativePath.trim();
    if (path.startsWith('http://') || path.startsWith('https://')) return path;
    final base = ApiService.baseUrl;
    if (base.endsWith('/api')) {
      final root = base.substring(0, base.length - 4);
      if (path.startsWith('/')) path = path.substring(1);
      return '$root/$path';
    } else {
      if (path.startsWith('/')) path = path.substring(1);
      return '$base/$path';
    }
  }

  List<Map<String, dynamic>> get _allServicesWithDefaults {
    final List<Map<String, dynamic>> targetServices = [
      {
        'id': 'pan',
        'name': 'PAN Card',
        'category': 'Home Product',
        'asset_image': 'assets/PAN.png',
        'icon': 'credit_card',
        'color': '#00A896',
      },
      {
        'id': 'aadhaar',
        'name': 'Aadhaar Card',
        'category': 'Home Product',
        'asset_image': 'assets/Aadhaar.png',
        'icon': 'fingerprint',
        'color': '#0284C7',
      },
      {
        'id': 'voter',
        'name': 'Voter ID',
        'category': 'Home Product',
        'asset_image': 'assets/Voter.png',
        'icon': 'how_to_vote',
        'color': '#E56B6F',
      },
      {
        'id': 'gst',
        'name': 'GST Registration',
        'category': 'Home Product',
        'asset_image': 'assets/GST.png',
        'icon': 'receipt_long',
        'color': '#F97316',
      },
      {
        'id': 'fastag_purchase',
        'name': 'Fastag Purchase',
        'category': 'Home Product',
        'asset_image': 'assets/Fastag Purchase.png',
        'icon': 'directions_car',
        'color': '#00A896',
      },
      {
        'id': 'dsc',
        'name': 'DSC',
        'category': 'Home Product',
        'asset_image': 'assets/DSC.png',
        'icon': 'verified_user',
        'color': '#00A896',
      },
      {
        'id': 'msme',
        'name': 'MSME',
        'category': 'Home Product',
        'asset_image': 'assets/MSME.png',
        'icon': 'storefront',
        'color': '#0284C7',
      },
      {
        'id': 'fssai',
        'name': 'FSSAI',
        'category': 'Home Product',
        'asset_image': 'assets/FSSAI.png',
        'icon': 'restaurant',
        'color': '#F97316',
      },
      {
        'id': 'passport',
        'name': 'Passport Services',
        'category': 'Home Product',
        'asset_image': 'assets/PassPort.png',
        'icon': 'flight_takeoff',
        'color': '#00A896',
      },
      {
        'id': 'aeps',
        'name': 'AEPS',
        'category': 'Payment Services',
        'asset_image': 'assets/AEPS.png',
        'icon': 'account_balance',
        'color': '#0284C7',
      },
      {
        'id': 'landline_bbps',
        'name': 'Landline',
        'category': 'BBPS Services',
        'asset_image': 'assets/Landline.jpg',
        'icon': 'phone_in_talk',
        'color': '#2563EB',
      },
      {
        'id': 'dth_bbps',
        'name': 'DTH Recharge',
        'category': 'BBPS Services',
        'asset_image': 'assets/DTH.png',
        'icon': 'tv',
        'color': '#6D28D9',
      },
      {
        'id': 'electricity_bbps',
        'name': 'Electricity Bill',
        'category': 'BBPS Services',
        'asset_image': 'assets/Electricity.png',
        'icon': 'bolt',
        'color': '#0284C7',
      },
      {
        'id': 'piped_gas_bbps',
        'name': 'Piped Gas Bill',
        'category': 'BBPS Services',
        'asset_image': 'assets/Piped Gas Bill.jpg',
        'icon': 'propane_tank',
        'color': '#0EA5E9',
      },
      {
        'id': 'gas_cylinder_bbps',
        'name': 'Gas Cylinder',
        'category': 'BBPS Services',
        'asset_image': 'assets/Gas.jpg',
        'icon': 'propane_tank',
        'color': '#E11D48',
      },
      {
        'id': 'water_bbps',
        'name': 'Water Bill',
        'category': 'BBPS Services',
        'asset_image': 'assets/Waters.png',
        'icon': 'water_drop',
        'color': '#0284C7',
      },
      {
        'id': 'education_bbps',
        'name': 'Education Fees',
        'category': 'BBPS Services',
        'asset_image': 'assets/Education.png',
        'icon': 'school',
        'color': '#4F46E5',
      },
      {
        'id': 'loan_payment_bbps',
        'name': 'Loan Repayment',
        'category': 'BBPS Services',
        'asset_image': 'assets/Loan Payment.png',
        'icon': 'account_balance_wallet',
        'color': '#FF5722',
      },
      {
        'id': 'municipal_taxes_bbps',
        'name': 'Municipal Taxes',
        'category': 'BBPS Services',
        'asset_image': 'assets/Muncipal Taxes.png',
        'icon': 'location_city',
        'color': '#F97316',
      },
      {
        'id': 'recharge',
        'name': 'Mobile Recharge',
        'category': 'BBPS Services',
        'asset_image': 'assets/Postpaid Mobile Recharges.png',
        'icon': 'phone_android',
        'color': '#059669',
      },
      {
        'id': 'housing_society_bbps',
        'name': 'Housing Society',
        'category': 'BBPS Services',
        'asset_image': 'assets/Housing Society.png',
        'icon': 'home_work',
        'color': '#5A80F6',
      },
      {
        'id': 'fastag_bbps',
        'name': 'FASTag Recharge',
        'category': 'BBPS Services',
        'asset_image': 'assets/Fastag.png',
        'icon': 'directions_car',
        'color': '#FF2D6C',
      },
      {
        'id': 'metro_card_bbps',
        'name': 'Metro Card Recharge',
        'category': 'BBPS Services',
        'asset_image': 'assets/Metro card Recharge.png',
        'icon': 'subway',
        'color': '#FF7D54',
      },
      {
        'id': 'broadband_bbps',
        'name': 'Broadband Bill',
        'category': 'BBPS Services',
        'asset_image': 'assets/Broadband.png',
        'icon': 'router',
        'color': '#6366F1',
      },
      {
        'id': 'insurance_bbps',
        'name': 'Insurance Premium',
        'category': 'BBPS Services',
        'asset_image': 'assets/Insurance premium.png',
        'icon': 'health_and_safety',
        'color': '#A855F7',
      },
      {
        'id': 'money_transfer_payment',
        'name': 'Money Transfer',
        'category': 'Payment Services',
        'asset_image': 'assets/Money Transfer.png',
        'icon': 'swap_horiz',
        'color': '#00A896',
      },
    ];
    targetServices.addAll(eGovernmentServicesList);
    targetServices.addAll(travelsServicesList);

    final result = <Map<String, dynamic>>[];
    final rawList = List<Map<String, dynamic>>.from(widget.services);

    for (final item in targetServices) {
      final nameKey = item['id'].toString();

      final match = rawList.firstWhere((s) {
        final n = (s['name'] ?? '').toString().toLowerCase();
        if (nameKey == 'aadhaar' && n.contains('aadhaar')) return true;
        if (nameKey == 'pan' && n.contains('pan')) return true;
        if (nameKey == 'gst' && n.contains('gst')) return true;
        if (nameKey == 'voter' && n.contains('voter')) return true;
        if (nameKey == 'aeps' && n.contains('aeps')) return true;
        if (nameKey == 'landline_bbps' && n.contains('landline')) return true;
        if (nameKey == 'dth_bbps' && n.contains('dth')) return true;
        if (nameKey == 'electricity_bbps' && n.contains('electricity')) {
          return true;
        }
        if (nameKey == 'piped_gas_bbps' && n.contains('piped gas')) return true;
        if (nameKey == 'gas_cylinder_bbps' &&
            (n.contains('cylinder') || n.contains('gas cylinder'))) {
          return true;
        }
        if (nameKey == 'water_bbps' && n.contains('water')) return true;
        if (nameKey == 'education_bbps' &&
            (n.contains('education') || n.contains('fee'))) {
          return true;
        }
        if (nameKey == 'loan_payment_bbps' &&
            (n.contains('loan') || n.contains('repayment'))) {
          return true;
        }
        if (nameKey == 'municipal_taxes_bbps' &&
            (n.contains('municipal') || n.contains('tax'))) {
          return true;
        }
        if (nameKey == 'recharge' &&
            !n.contains('fastag') && !n.contains('metro') && !n.contains('dth') &&
            (n.contains('recharge') || n.contains('mobile'))) {
          return true;
        }
        if (nameKey == 'housing_society_bbps' &&
            (n.contains('housing') || n.contains('society'))) {
          return true;
        }
        if (nameKey == 'fastag_purchase' &&
            n.contains('fastag') && n.contains('purchase')) {
          return true;
        }
        if (nameKey == 'fastag_bbps' &&
            n.contains('fastag') && (n.contains('recharge') || n.contains('toll') || !n.contains('purchase'))) {
          return true;
        }
        if (nameKey == 'metro_card_bbps' &&
            (n.contains('metro') || n.contains('subway'))) {
          return true;
        }
        if (nameKey == 'broadband_bbps' &&
            (n.contains('broadband') || n.contains('fiber'))) {
          return true;
        }
        if (nameKey == 'insurance_bbps' &&
            (n.contains('insurance') || n.contains('policy'))) {
          return true;
        }
        if (nameKey == 'money_transfer_payment' &&
            (n.contains('money') ||
                n.contains('dmt') ||
                n.contains('transfer'))) {
          return true;
        }
        return false;
      }, orElse: () => item);

      final merged = Map<String, dynamic>.from(match);
      merged['category'] = item['category'];
      if (item['asset_image'] != null &&
          (item['asset_image'] as String).isNotEmpty) {
        merged['asset_image'] = item['asset_image'];
      }
      if (item['url'] != null && (item['url'] as String).isNotEmpty) {
        merged['url'] = item['url'];
      }
      if (merged['color'] == null) {
        merged['color'] = item['color'];
      }
      result.add(merged);
    }

    return result;
  }

  bool _isMunicipalTaxesService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return name.contains('municipal') ||
        name.contains('tax') ||
        category.contains('municipal');
  }

  bool _isLoanPaymentService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return name.contains('loan') ||
        name.contains('repayment') ||
        category.contains('loan');
  }

  bool _isWaterService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return name.contains('water') || category.contains('water');
  }

  bool _isEducationService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return name.contains('education') ||
        name.contains('school') ||
        name.contains('college') ||
        category.contains('education');
  }

  bool _isLandlineService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return name.contains('landline') || category.contains('landline');
  }

  bool _isDthService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return name.contains('dth') || category.contains('dth');
  }

  bool _isElectricityService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return name.contains('electricity') || category.contains('electricity');
  }

  bool _isPipedGasService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return name.contains('piped gas') || category.contains('piped gas');
  }

  bool _isGasCylinderService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return name.contains('cylinder') ||
        category.contains('cylinder') ||
        name.contains('lpg');
  }

  bool _isRechargeService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    if (name.contains('fastag') ||
        name.contains('dth') ||
        name.contains('metro')) {
      return false;
    }
    return name.contains('recharge') || category.contains('recharge');
  }

  bool _isHousingSocietyService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return name.contains('housing') ||
        name.contains('society') ||
        category.contains('housing');
  }

  bool _isFastagPurchaseService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final id   = (service['id'] ?? '').toString().toLowerCase();
    return id == 'fastag_purchase' || (name.contains('fastag') && name.contains('purchase'));
  }

  bool _isFastagRechargeService(Map<String, dynamic> service) {
    final name     = (service['name'] ?? '').toString().toLowerCase();
    final id       = (service['id'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return id == 'fastag_bbps' ||
        (name.contains('fastag') && (name.contains('recharge') || category.contains('bbps') || !name.contains('purchase'))) ||
        name.contains('toll');
  }

  bool _isMetroCardService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return name.contains('metro') ||
        name.contains('subway') ||
        category.contains('metro');
  }

  bool _isBroadbandService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return name.contains('broadband') ||
        name.contains('fiber') ||
        category.contains('broadband');
  }

  bool _isInsuranceService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    return name.contains('insurance') ||
        name.contains('policy') ||
        category.contains('insurance');
  }

  bool _isMoneyTransferService(Map<String, dynamic> service) {
    final name = (service['name'] ?? '').toString().toLowerCase();
    final category = (service['category'] ?? '').toString().toLowerCase();
    if (name.contains('aeps')) return false;
    return name.contains('money') ||
        name.contains('dmt') ||
        name.contains('remitter') ||
        (category.contains('payment') &&
            (name.contains('transfer') || name.contains('money')));
  }

  List<Map<String, dynamic>> get _categoriesWithCount {
    final cats = <String, int>{};
    for (var s in _allServicesWithDefaults) {
      final cat = (s['category'] ?? 'Other').toString().trim();
      if (cat.isNotEmpty) cats[cat] = (cats[cat] ?? 0) + 1;
    }
    final list = cats.entries
        .map((e) => {'name': e.key, 'count': e.value})
        .toList();
    list.sort((a, b) {
      final nameA = a['name'] as String;
      final nameB = b['name'] as String;
      if (nameA == 'Home Product') return -1;
      if (nameB == 'Home Product') return 1;
      return nameA.compareTo(nameB);
    });
    return list;
  }

  List<Map<String, dynamic>> get _filteredServices {
    final seen = <String>{};
    final unique = _allServicesWithDefaults.where((s) {
      final name = (s['name'] ?? '').toString().trim();
      if (seen.contains(name)) return false;
      seen.add(name);
      return true;
    }).toList();

    return unique.where((s) {
      final name = (s['name'] ?? '').toString().toLowerCase().trim();
      final cat = (s['category'] ?? '').toString().trim();
      final matchesSearch =
          _searchQuery.isEmpty ||
          name.contains(_searchQuery.toLowerCase().trim());

      bool matchesCategory;
      if (_selectedCategory == 'Home Product') {
        if (_searchQuery.isEmpty) {
          matchesCategory = cat == 'Home Product';
        } else {
          matchesCategory = true;
        }
      } else if (_selectedCategory == 'All') {
        matchesCategory = true;
      } else {
        matchesCategory = cat == _selectedCategory;
      }

      return matchesSearch && matchesCategory;
    }).toList();
  }

  Future<void> _onServiceTap(Map<String, dynamic> service) async {
    final String sId = (service['id'] ?? '').toString();
    final String sName = (service['name'] ?? '').toString().toLowerCase();

    if (sId == 'travel_irtc' || sId == 'travel_flight' || sName.contains('irtc') || sName.contains('flight booking')) {
      showComingSoonDialog(context);
      return;
    }

    if (sId == 'travel_bus' || sName.contains('bus booking') || sName.contains('bus ticket')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const BusBookingScreen()),
      );
      return;
    }

    final String? portalUrl = service['url']?.toString();
    if (portalUrl != null && portalUrl.trim().isNotEmpty) {
      final uri = Uri.parse(portalUrl.trim());
      try {
        final launched = await launchUrl(
          uri,
          mode: LaunchMode.externalApplication,
        );
        if (!launched) {
          await launchUrl(uri, mode: LaunchMode.platformDefault);
        }
      } catch (_) {
        try {
          await launchUrl(uri, mode: LaunchMode.platformDefault);
        } catch (_) {}
      }
      return;
    }

    if (_isLandlineService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const LandlineScreen()),
      );
      return;
    }

    if (_isDthService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const DTHScreen()),
      );
      return;
    }

    if (_isElectricityService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ElectricityScreen()),
      );
      return;
    }

    if (_isPipedGasService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const PipedGasBillScreen()),
      );
      return;
    }

    if (_isGasCylinderService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const GasCylinderScreen()),
      );
      return;
    }

    if (_isWaterService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const WaterScreen()),
      );
      return;
    }

    if (_isEducationService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const EducationScreen()),
      );
      return;
    }

    if (_isLoanPaymentService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const LoanPaymentScreen()),
      );
      return;
    }

    if (_isMunicipalTaxesService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const MunicipalTaxesScreen()),
      );
      return;
    }

    if (_isFastagPurchaseService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => FastagPurchaseScreen(
            service: service,
            isGuest: widget.isGuest,
          ),
        ),
      );
      return;
    }

    if (_isFastagRechargeService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const FastagScreen()),
      );
      return;
    }

    if (_isMetroCardService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const MetroCardScreen()),
      );
      return;
    }

    if (_isBroadbandService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const BroadbandScreen()),
      );
      return;
    }

    if (_isInsuranceService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const InsuranceScreen()),
      );
      return;
    }

    if (_isMoneyTransferService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const MoneyTransferScreen()),
      );
      return;
    }

    if (_isHousingSocietyService(service)) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const HousingSocietyScreen()),
      );
      return;
    }

    if (_isRechargeService(service)) {
      _showRechargePopupDialog(service);
      return;
    }

    final rawId = service['id'];
    final intId = rawId is int ? rawId : int.tryParse(rawId?.toString() ?? '');

    List<Map<String, dynamic>> sections = [];

    if (intId != null) {
      setState(() => _loadingSections = true);
      try {
        final result = await _api
            .getServiceSections(intId)
            .timeout(const Duration(milliseconds: 1500));
        sections =
            (result['sections'] as List?)?.cast<Map<String, dynamic>>() ?? [];
      } catch (_) {}
      if (!mounted) return;
      setState(() => _loadingSections = false);
    }

    if (sections.isEmpty) {
      final sName = (service['name'] ?? '').toString().toLowerCase();
      if (sName.contains('voter')) {
        sections = [
          {'id': 101, 'section_name': 'New Voter ID Application'},
          {'id': 102, 'section_name': 'Voter ID Correction / Update'},
          {'id': 103, 'section_name': 'Download E-Voter Card'},
        ];
      } else if (sName.contains('pan')) {
        sections = [
          {'id': 201, 'section_name': 'New PAN Card Application'},
          {'id': 202, 'section_name': 'Correction / Update PAN'},
          {'id': 203, 'section_name': 'Foreign PAN Application'},
        ];
      } else if (sName.contains('gst')) {
        sections = [
          {'id': 301, 'section_name': 'GST Registration'},
        ];
      } else if (sName.contains('aadhaar') || sName.contains('aadhar')) {
        sections = [
          {'id': 401, 'section_name': 'Soft Copy'},
          {'id': 402, 'section_name': 'Hard Copy'},
        ];
      } else if (sName.contains('aeps')) {
        sections = [
          {'id': 501, 'section_name': 'Cash Withdrawal'},
          {'id': 502, 'section_name': 'Balance Enquiry'},
          {'id': 503, 'section_name': 'Mini Statement'},
        ];
      } else if (sName.contains('driving') || sName.contains('dl')) {
        sections = [
          {'id': 601, 'section_name': 'New Driving License'},
          {'id': 602, 'section_name': 'DL Renewal'},
          {'id': 603, 'section_name': 'Duplicate DL'},
        ];
      } else if (sName.contains('passport')) {
        sections = [
          {'id': 701, 'section_name': 'New Passport Application'},
          {'id': 702, 'section_name': 'Passport Renewal'},
          {'id': 703, 'section_name': 'Track Passport Status'},
        ];
      } else if (sName.contains('itr') || sName.contains('tax')) {
        sections = [
          {'id': 801, 'section_name': 'ITR Filing'},
          {'id': 802, 'section_name': 'Tax Calculator'},
          {'id': 803, 'section_name': 'Form 16 Upload'},
        ];
      }
    }

    if (sections.length > 1) {
      _showSectionPopup(service, sections);
    } else {
      _openDetail(
        service,
        sections.isNotEmpty ? Map<String, dynamic>.from(sections.first) : null,
      );
    }
  }

  void _openDetail(
    Map<String, dynamic> service,
    Map<String, dynamic>? section,
  ) {
    final sName = (service['name'] ?? '').toString().toLowerCase();
    Widget targetScreen;

    if (sName.contains('aadhaar') || sName.contains('aadhar')) {
      targetScreen = AadhaarServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('pan')) {
      targetScreen = PanServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('gst')) {
      targetScreen = GstServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('voter')) {
      targetScreen = VoterIdServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('dsc')) {
      targetScreen = DscServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('msme') || sName.contains('udyam')) {
      targetScreen = MsmeServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('fssai') || sName.contains('food')) {
      targetScreen = FssaiServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('passport')) {
      targetScreen = PassportServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else {
      targetScreen = ServiceDetailScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    }

    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, a, b) => targetScreen,
        transitionsBuilder: (_, animation, _, child) {
          return SlideTransition(
            position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
                .animate(animation),
            child: child,
          );
        },
        transitionDuration: const Duration(milliseconds: 350),
      ),
    );
  }

  void _showRechargePopupDialog(Map<String, dynamic> service) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withAlpha(150),
      builder: (ctx) {
        return Dialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 440),
            padding: const EdgeInsets.fromLTRB(16, 16, 12, 20),
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Mobile Recharge Services',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF0F172A),
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close_rounded, color: Color(0xFF64748B), size: 22),
                        onPressed: () => Navigator.pop(ctx),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Divider(height: 1, color: Color(0xFFE2E8F0)),
                  const SizedBox(height: 16),

                  InkWell(
                    onTap: () {
                      Navigator.pop(ctx);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const RechargeScreen(initialIsPostpaid: false),
                        ),
                      );
                    },
                    borderRadius: BorderRadius.circular(14),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFF00A896).withAlpha(50), width: 1.5),
                      ),
                      child: const Row(
                        children: [
                          CircleAvatar(
                            radius: 18,
                            backgroundColor: Color(0xFF00A896),
                            child: Icon(Icons.phone_android_rounded, color: Colors.white, size: 18),
                          ),
                          SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Prepaid Mobile Recharge',
                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5, color: Color(0xFF0F172A)),
                                ),
                                SizedBox(height: 2),
                                Text('Instant top-up for all prepaid plans', style: TextStyle(fontSize: 11, color: Color(0xFF64748B))),
                              ],
                            ),
                          ),
                          Icon(Icons.chevron_right_rounded, color: Color(0xFF00A896)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  InkWell(
                    onTap: () {
                      Navigator.pop(ctx);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const RechargeScreen(initialIsPostpaid: true),
                        ),
                      );
                    },
                    borderRadius: BorderRadius.circular(14),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFF0284C7).withAlpha(50), width: 1.5),
                      ),
                      child: const Row(
                        children: [
                          CircleAvatar(
                            radius: 18,
                            backgroundColor: Color(0xFF0284C7),
                            child: Icon(Icons.receipt_long_rounded, color: Colors.white, size: 18),
                          ),
                          SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Postpaid Mobile Recharges',
                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5, color: Color(0xFF0F172A)),
                                ),
                                SizedBox(height: 2),
                                Text('Pay monthly postpaid mobile bills', style: TextStyle(fontSize: 11, color: Color(0xFF64748B))),
                              ],
                            ),
                          ),
                          Icon(Icons.chevron_right_rounded, color: Color(0xFF0284C7)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showPassportPopupDialog(Map<String, dynamic> service) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withAlpha(150),
      builder: (ctx) {
        return Dialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 480),
            padding: const EdgeInsets.fromLTRB(20, 16, 16, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Service Details',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF333333),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close_rounded, color: Color(0xFF666666), size: 24),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                const Divider(height: 1, color: Color(0xFFE2E8F0)),
                const SizedBox(height: 20),

                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    // 1. GREEN BUTTON: NEW PASSPORT ▼
                    PopupMenuButton<int>(
                      offset: const Offset(0, 42),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      color: Colors.white,
                      elevation: 6,
                      onSelected: (int selectedId) {
                        Navigator.pop(ctx);
                        _openDetail(service, {'id': selectedId});
                      },
                      itemBuilder: (context) => [
                        const PopupMenuItem(
                          value: 1,
                          child: Text('Normal (passport)', style: TextStyle(fontSize: 13, color: Color(0xFF333333))),
                        ),
                        const PopupMenuItem(
                          value: 2,
                          child: Text('Tatkal (passport)', style: TextStyle(fontSize: 13, color: Color(0xFF333333))),
                        ),
                        const PopupMenuItem(
                          value: 3,
                          child: Text('Minor Passport', style: TextStyle(fontSize: 13, color: Color(0xFF333333))),
                        ),
                      ],
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF0F9D58),
                          borderRadius: BorderRadius.circular(8),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF0F9D58).withAlpha(60),
                              blurRadius: 6,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'NEW PASSPORT',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12.5,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                              ),
                            ),
                            SizedBox(width: 4),
                            Icon(Icons.arrow_drop_down, color: Colors.white, size: 18),
                          ],
                        ),
                      ),
                    ),

                    // 2. ORANGE/YELLOW BUTTON: CORRECTION PASSPORT ▼
                    PopupMenuButton<int>(
                      offset: const Offset(0, 42),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      color: Colors.white,
                      elevation: 6,
                      onSelected: (int selectedId) {
                        Navigator.pop(ctx);
                        _openDetail(service, {'id': selectedId});
                      },
                      itemBuilder: (context) => [
                        const PopupMenuItem(
                          value: 4,
                          child: Text('1st Correction / Renewal passport', style: TextStyle(fontSize: 13, color: Color(0xFF333333))),
                        ),
                        const PopupMenuItem(
                          value: 5,
                          child: Text('2nd Correction / Renewal tatkal passport', style: TextStyle(fontSize: 13, color: Color(0xFF333333))),
                        ),
                        const PopupMenuItem(
                          value: 6,
                          child: Text('3rd Lost / Damage passport', style: TextStyle(fontSize: 13, color: Color(0xFF333333))),
                        ),
                      ],
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE69719),
                          borderRadius: BorderRadius.circular(8),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFE69719).withAlpha(60),
                              blurRadius: 6,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'CORRECTION PASSPORT',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12.5,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                              ),
                            ),
                            SizedBox(width: 4),
                            Icon(Icons.arrow_drop_down, color: Colors.white, size: 18),
                          ],
                        ),
                      ),
                    ),

                    // 3. PCC BUTTON
                    InkWell(
                      onTap: () {
                        Navigator.pop(ctx);
                        _openDetail(service, {'id': 7});
                      },
                      borderRadius: BorderRadius.circular(8),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF00A896),
                          borderRadius: BorderRadius.circular(8),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF00A896).withAlpha(60),
                              blurRadius: 6,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: const Text(
                          'PCC',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12.5,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showSectionPopup(Map<String, dynamic> service, List<dynamic> sections) {
    const tealPrimary = Color(0xFF00A896);
    const tealDark = Color(0xFF0284C7);

    List<dynamic> effectiveSections = List.from(sections);
    final serviceName = (service['name'] ?? '').toString().toLowerCase();
    if (serviceName.contains('passport')) {
      _showPassportPopupDialog(service);
      return;
    }

    if (serviceName.contains('pan')) {
      effectiveSections = [
        {'id': 202, 'section_name': 'Correction PAN'},
        {'id': 201, 'section_name': 'New PAN'},
        {'id': 203, 'section_name': 'Foreign PAN'},
        {'id': 204, 'section_name': 'Find PAN'},
      ];
    } else if (serviceName.contains('voter')) {
      effectiveSections = [
        {'id': 101, 'section_name': 'Voter ID'},
        {'id': 102, 'section_name': 'Correction Voter ID'},
        {'id': 103, 'section_name': 'Voter Print Hard Copy'},
        {'id': 104, 'section_name': 'Voter Print Soft Copy'},
      ];
    }

    showDialog(
      context: context,
      barrierColor: Colors.black.withAlpha(190),
      builder: (ctx) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 20),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 440),
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(28),
              boxShadow: [
                BoxShadow(
                  color: tealPrimary.withAlpha(60),
                  blurRadius: 30,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Top Header Banner with Teal Gradient
                Container(
                  padding: const EdgeInsets.fromLTRB(20, 20, 16, 20),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [tealPrimary, tealDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: Colors.white.withAlpha(45),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(
                          Icons.assignment_rounded,
                          color: Colors.white,
                          size: 26,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              (service['name'] ?? 'Service Option').toString(),
                              style: const TextStyle(
                                fontSize: 19,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 2),
                            const Text(
                              'Select an option to proceed',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.white70,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close_rounded, color: Colors.white, size: 22),
                        onPressed: () => Navigator.pop(ctx),
                      ),
                    ],
                  ),
                ),

                // List of Section Options with Modern Cards
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: effectiveSections.map((sec) {
                      final section = Map<String, dynamic>.from(sec);
                      final secName = (section['section_name'] ?? '').toString();
                      final isSoft = secName.toLowerCase().contains('soft');
                      final isHard = secName.toLowerCase().contains('hard');
                      final isFind = secName.toLowerCase().contains('find');
                      final isNew = secName.toLowerCase().contains('new');
                      final isForeign = secName.toLowerCase().contains('foreign');

                      IconData secIcon = Icons.credit_card_rounded;
                      String subtitle = 'Complete application details';
                      if (isSoft) {
                        secIcon = Icons.picture_as_pdf_rounded;
                        subtitle = 'Instant E-Aadhaar Digital Soft Copy';
                      } else if (isHard) {
                        secIcon = Icons.credit_card_rounded;
                        subtitle = 'Physical PVC Card Delivered to Address';
                      } else if (isFind) {
                        secIcon = Icons.search_rounded;
                        subtitle = 'Find existing PAN by Aadhaar number';
                      } else if (isNew) {
                        secIcon = Icons.add_card_rounded;
                        subtitle = 'Apply for new PAN card';
                      } else if (isForeign) {
                        secIcon = Icons.language_rounded;
                        subtitle = 'Apply for Foreign PAN card';
                      }

                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: () {
                              Navigator.pop(ctx);
                              _openDetail(service, section);
                            },
                            borderRadius: BorderRadius.circular(16),
                            child: Container(
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: tealPrimary.withAlpha(50),
                                  width: 1.5,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withAlpha(8),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 42,
                                    height: 42,
                                    decoration: BoxDecoration(
                                      color: tealPrimary.withAlpha(20),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Icon(secIcon, color: tealPrimary, size: 22),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          secName,
                                          style: const TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xFF1E293B),
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          subtitle,
                                          style: const TextStyle(
                                            fontSize: 11,
                                            color: Color(0xFF64748B),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const Icon(
                                    Icons.arrow_forward_ios_rounded,
                                    size: 16,
                                    color: tealPrimary,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filteredServices;
    final categories = _categoriesWithCount;

    return Scaffold(
      backgroundColor: bgCream,
      appBar: AppBar(
        backgroundColor: bgCream,
        elevation: 0,
        title: const Text(
          'All Services',
          style: TextStyle(
            color: textDark,
            fontWeight: FontWeight.w800,
            fontSize: 20,
            letterSpacing: 0.2,
          ),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new,
            color: primaryOrange,
            size: 18,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTopSearchCard(),
              _buildMoreServicesHeader(),
              if (categories.isNotEmpty) _buildCategoryChips(categories),
              const SizedBox(height: 8),
              Expanded(
                child: filtered.isEmpty
                    ? _buildEmptyState()
                    : _buildImageGrid(filtered),
              ),
            ],
          ),
          if (_loadingSections)
            Container(
              color: Colors.black26,
              child: const Center(
                child: CircularProgressIndicator(color: primaryOrange),
              ),
            ),
        ],
      ),
    );
  }

  // ==================== TOP SEARCH BOX HERO CARD (MATCHING SCREENSHOT) ====================
  Widget _buildTopSearchCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color.fromARGB(255, 32, 123, 129),
            Color.fromARGB(255, 37, 222, 235),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: const Color.fromARGB(255, 97, 123, 195).withAlpha(80),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Explore All Services',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              letterSpacing: 0.2,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Enter service or category to start search',
            style: TextStyle(fontSize: 13, color: Colors.white.withAlpha(210)),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withAlpha(10),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      const SizedBox(width: 12),
                      const Icon(
                        Icons.search_rounded,
                        color: Color(0xFF64748B),
                        size: 22,
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: TextField(
                          onChanged: (v) => setState(() => _searchQuery = v),
                          style: const TextStyle(
                            color: textDark,
                            fontSize: 13.5,
                          ),
                          decoration: const InputDecoration(
                            hintText: 'For ex: Electricity, PAN, DTH...',
                            hintStyle: TextStyle(
                              color: Color(0xFFA1A1AA),
                              fontSize: 12.5,
                              fontWeight: FontWeight.w400,
                            ),
                            border: InputBorder.none,
                            isDense: true,
                            contentPadding: EdgeInsets.symmetric(vertical: 14),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: const Color(0xFFF97316),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFF97316).withAlpha(90),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.tune_rounded,
                  color: Colors.white,
                  size: 24,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMoreServicesHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              _selectedCategory,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: textDark,
                letterSpacing: 0.2,
              ),
            ),
          ),
          IconButton(
            icon: const Icon(
              Icons.swap_vert_rounded,
              color: textDark,
              size: 22,
            ),
            onPressed: () {
              setState(() {
                // Refresh list sorting
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryChips(List<Map<String, dynamic>> categories) {
    return SizedBox(
      height: 38,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final cat = categories[index];
          final name = cat['name'] as String;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: _buildChip(
              name,
              _selectedCategory == name,
              cat['count'] as int,
            ),
          );
        },
      ),
    );
  }

  Widget _buildChip(String label, bool selected, int count) {
    return GestureDetector(
      onTap: () => setState(() => _selectedCategory = label),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? const Color.fromARGB(255, 52, 174, 176) : cardWhite,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected
                ? const Color.fromARGB(255, 58, 174, 184)
                : Colors.grey[300]!,
          ),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: const Color.fromARGB(
                      255,
                      53,
                      166,
                      184,
                    ).withAlpha(40),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ]
              : null,
        ),
        child: Text(
          '$label ($count)',
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: selected ? Colors.white : textDark,
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.search_off_rounded, size: 60, color: Colors.grey[300]),
          const SizedBox(height: 16),
          const Text(
            'No services found',
            style: TextStyle(color: textDark, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildImageGrid(List<Map<String, dynamic>> services) {
    final width = MediaQuery.of(context).size.width;
    final crossAxisCount = (width / 120).floor().clamp(3, 6);

    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      physics: const BouncingScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        mainAxisSpacing: 14,
        crossAxisSpacing: 14,
        childAspectRatio: 0.80,
      ),
      itemCount: services.length,
      itemBuilder: (context, index) {
        final s = services[index];
        final String name = (s['name'] ?? '').toString().trim();
        final Color color = _parseColor(s['color']);
        final IconData icon = _parseIcon(s['icon']);
        final String imageUrl = _imageUrl(s['image_url']?.toString());
        final String assetImg = (s['asset_image'] ?? '').toString();
        final lower = name.toLowerCase();
        final isEnlargedTarget =
            lower.contains('dth') ||
            lower.contains('electricity') ||
            lower.contains('piped') ||
            lower.contains('gas') ||
            lower.contains('water') ||
            lower.contains('education') ||
            lower.contains('loan') ||
            lower.contains('municipal') ||
            lower.contains('recharge') ||
            lower.contains('mobile') ||
            lower.contains('house') ||
            lower.contains('housing') ||
            lower.contains('fastag') ||
            lower.contains('metro') ||
            lower.contains('broad') ||
            lower.contains('insurance');
        final double logoSize = isEnlargedTarget ? 88.0 : 72.0;

        return GestureDetector(
          onTap: () => _onServiceTap(s),
          child: Container(
            decoration: BoxDecoration(
              color: cardWhite,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: color.withAlpha(40), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: color.withAlpha(20),
                  blurRadius: 14,
                  offset: const Offset(0, 5),
                ),
                BoxShadow(
                  color: Colors.black.withAlpha(6),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  width: logoSize,
                  height: logoSize,
                  child: Center(
                    child: _buildServiceLogoWidget(
                      name,
                      color,
                      icon,
                      assetImg,
                      imageUrl,
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    name,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: textDark,
                      height: 1.2,
                    ),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildServiceLogoWidget(
    String name,
    Color color,
    IconData icon,
    String localAsset,
    String imageUrl,
  ) {
    final lower = name.toLowerCase();

    String assetPath = localAsset;
    if (!lower.contains('landline') && assetPath.contains('Landline.jpg')) {
      assetPath = '';
    }

    if (lower.contains('irctc') || lower.contains('irtc')) {
      assetPath = 'assets/IRCTC.png';
    } else if (lower.contains('nadakacheri')) {
      assetPath = 'assets/Nadakacheri.png';
    } else if (lower.contains('rtc') || lower.contains('pahani')) {
      assetPath = 'assets/RTC MR.png';
    } else if (lower.contains('kaveri')) {
      assetPath = 'assets/Kaveri.png';
    } else if (lower.contains('khajane') ||
        lower.contains('k town') ||
        lower.contains('k2') ||
        lower.contains('k two') ||
        lower.contains('challen')) {
      assetPath = 'assets/K Town.png';
    } else if (lower.contains('eswathu')) {
      assetPath = 'assets/Eswathu.png';
    } else if (lower.contains('sakala')) {
      assetPath = 'assets/Sakala.png';
    } else if (lower.contains('bbmp')) {
      assetPath = 'assets/BBMP.png';
    } else if (lower.contains('land build') ||
        lower.contains('land buld') ||
        lower.contains('nirmana') ||
        lower.contains('aprv')) {
      assetPath = 'assets/Land Build.png';
    } else if (lower.contains('panchayat') || lower.contains('bsk')) {
      assetPath = 'assets/Panchayat Tax.png';
    } else if (lower.contains('jalanidhi')) {
      assetPath = 'assets/Jalanidhi.png';
    } else if (lower.contains('tn urban')) {
      assetPath = 'assets/TN Urban Tax.png';
    } else if (lower.contains('chennai')) {
      assetPath = 'assets/Chennai Corp.png';
    } else if (lower == 'tn govt' || lower.contains('tn govt')) {
      assetPath = 'assets/TN GOVT.png';
    } else if (lower.contains('tn land')) {
      assetPath = 'assets/TN Land Survey.png';
    } else if (lower.contains('revenu')) {
      assetPath = 'assets/Revenu.png';
    } else if (lower.contains('kerala bhoomi') || lower.contains('bhoomi')) {
      assetPath = 'assets/Kerala Bhoomi.png';
    } else if (lower.contains('lottery')) {
      assetPath = 'assets/Kerala Lottery.png';
    } else if (lower.contains('passport')) {
      assetPath = 'assets/PassPort.png';
    } else if (lower.contains('meesav')) {
      assetPath = 'assets/Meesav Telan.png';
    } else if (lower == 'ssp') {
      assetPath = 'assets/SSP.png';
    } else if (lower == 'nps' || lower.contains('nps')) {
      assetPath = 'assets/NPS.png';
    } else if (lower.contains('tn scholarship')) {
      assetPath = 'assets/TN Scholarship.png';
    } else if (lower.contains('whitehope')) {
      assetPath = 'assets/Whitehope.png';
    } else if (lower.contains('kerala state')) {
      assetPath = 'assets/Kerala State.png';
    } else if (lower.contains('ap schlor') || lower.contains('ap sch')) {
      assetPath = 'assets/AP Schlor.png';
    } else if (lower == 'scholarship') {
      assetPath = 'assets/scholarship.png';
    } else if (lower.contains('sc st kerala')) {
      assetPath = 'assets/Sc St Kerala.png';
    } else if (lower.contains('sc st tn')) {
      assetPath = 'assets/Sc st TN.png';
    } else if (lower == 'sc st' || lower.contains('sc st')) {
      assetPath = 'assets/SC ST.png';
    } else if (lower.contains('edu loan')) {
      assetPath = 'assets/Edu Loan.png';
    } else if (lower.contains('traffic')) {
      assetPath = 'assets/Traffic Payment.png';
    } else if (lower.contains('irtc')) {
      assetPath = 'assets/IRTC.png';
    } else if (lower.contains('flight')) {
      assetPath = 'assets/Flight Booking.png';
    } else if (lower.contains('bus')) {
      assetPath = 'assets/Bus booking.png';
    } else if (assetPath.isEmpty) {
      if (lower.contains('aadhaar')) assetPath = 'assets/Aadhaar.png';
      if (lower.contains('pan')) assetPath = 'assets/PAN.png';
      if (lower.contains('gst')) assetPath = 'assets/GST.png';
      if (lower.contains('voter')) assetPath = 'assets/Voter.png';
      if (lower.contains('fastag') || lower.contains('toll')) assetPath = 'assets/Fastag Purchase.png';
      if (lower.contains('dsc')) assetPath = 'assets/DSC.png';
      if (lower.contains('msme') || lower.contains('udyam')) assetPath = 'assets/MSME.png';
      if (lower.contains('fssai') || lower.contains('food')) assetPath = 'assets/FSSAI.png';
      if (lower.contains('passport')) assetPath = 'assets/PassPort.png';
      if (lower.contains('metro')) {
        assetPath = 'assets/Metro card Recharge.png';
      }
      if (lower.contains('broadband') || lower.contains('fiber')) {
        assetPath = 'assets/Broadband.png';
      }
      if (lower.contains('insurance') || lower.contains('premium')) {
        assetPath = 'assets/Insurance premium.png';
      }
      if (lower.contains('money') || lower.contains('transfer')) {
        assetPath = 'assets/Money Transfer.png';
      }
      if (lower.contains('municipal') || lower.contains('tax')) {
        assetPath = 'assets/Muncipal Taxes.png';
      }
      if (lower.contains('recharge') ||
          lower.contains('postpaid') ||
          lower.contains('mobile')) {
        assetPath = 'assets/Postpaid Mobile Recharges.png';
      }
    }

    if (assetPath.isNotEmpty) {
      return Image.asset(
        assetPath,
        width: double.infinity,
        height: double.infinity,
        fit: BoxFit.contain,
        errorBuilder: (c, e, s) => _buildFallbackIconBadge(icon, color),
      );
    }

    if (imageUrl.isNotEmpty) {
      return Image.network(
        imageUrl,
        width: double.infinity,
        height: double.infinity,
        fit: BoxFit.contain,
        errorBuilder: (c, e, s2) => _buildFallbackIconBadge(icon, color),
        loadingBuilder: (c, child, progress) =>
            progress == null ? child : _buildFallbackIconBadge(icon, color),
      );
    }

    return _buildFallbackIconBadge(icon, color);
  }

  Widget _buildFallbackIconBadge(IconData icon, Color color) {
    return Icon(icon, color: color, size: 50);
  }
}
