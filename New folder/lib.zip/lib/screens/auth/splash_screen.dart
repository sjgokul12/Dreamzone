import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../home/home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late final AnimationController _logoAc;
  late final AnimationController _textAc;
  late final AnimationController _barAc;
  late final AnimationController _pulseAc;

  late final Animation<double> _logoScale;
  late final Animation<double> _logoFade;
  late final Animation<double> _textFade;
  late final Animation<Offset> _textSlide;
  late final Animation<double> _barWidth;
  late final Animation<double> _pulseGlow;

  // Modern Futuristic Palette
  static const Color darkBgStart = Color(0xFF09131D);
  static const Color darkBgEnd = Color(0xFF0F2B3C);
  static const Color primaryTeal = Color(0xFF00A896);
  static const Color accentCyan = Color(0xFF0284C7);
  static const Color vibrantOrange = Color(0xFFFF5500);

  @override
  void initState() {
    super.initState();

    // Logo entrance animation (600ms)
    _logoAc = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    );
    _logoScale = Tween<double>(begin: 0.45, end: 1.0).animate(
      CurvedAnimation(parent: _logoAc, curve: Curves.easeOutBack),
    );
    _logoFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _logoAc, curve: const Interval(0.0, 0.7)),
    );

    // Continuous pulse glow animation
    _pulseAc = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _pulseGlow = Tween<double>(begin: 0.85, end: 1.15).animate(
      CurvedAnimation(parent: _pulseAc, curve: Curves.easeInOut),
    );

    // Text slide & fade animation (500ms)
    _textAc = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 550),
    );
    _textFade = CurvedAnimation(parent: _textAc, curve: Curves.easeOut);
    _textSlide = Tween<Offset>(
      begin: const Offset(0, 0.35),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _textAc, curve: Curves.easeOutCubic));

    // Progress bar animation (1400ms)
    _barAc = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );
    _barWidth = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _barAc, curve: Curves.easeInOutCubic),
    );

    // Start sequence
    _logoAc.forward().then((_) {
      _textAc.forward();
      _barAc.forward();
    });

    _loadAndGo();
  }

  Future<void> _loadAndGo() async {
    final auth = Provider.of<AuthProvider>(context, listen: false);

    await Future.wait([
      auth.loadServices(),
      Future.delayed(const Duration(milliseconds: 2200)),
    ]);

    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, animation, secondaryAnimation) =>
            const HomeScreen(isGuest: true),
        transitionsBuilder: (_, animation, secondaryAnimation, child) =>
            FadeTransition(opacity: animation, child: child),
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  @override
  void dispose() {
    _logoAc.dispose();
    _pulseAc.dispose();
    _textAc.dispose();
    _barAc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);
    final screenWidth = media.size.width;
    final screenHeight = media.size.height;
    final isSmall = screenWidth < 360;

    final logoSize = (screenWidth * 0.28).clamp(115.0, 165.0);
    final titleSize = isSmall ? 24.0 : (screenWidth * 0.065).clamp(26.0, 34.0);

    return Scaffold(
      body: Stack(
        children: [
          // Background Gradient matching App Theme
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [darkBgStart, darkBgEnd, Color(0xFF064E5A)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),

          // Ambient Background Glow Circles
          Positioned(
            top: -screenHeight * 0.12,
            right: -screenWidth * 0.25,
            child: ScaleTransition(
              scale: _pulseGlow,
              child: Container(
                width: screenWidth * 0.85,
                height: screenWidth * 0.85,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: primaryTeal.withAlpha(35),
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -screenHeight * 0.12,
            left: -screenWidth * 0.25,
            child: Container(
              width: screenWidth * 0.75,
              height: screenWidth * 0.75,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: accentCyan.withAlpha(45),
              ),
            ),
          ),

          // Main Content
          SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Spacer(flex: 2),

                      // Glassmorphic Glowing Logo Card
                      ScaleTransition(
                        scale: _logoScale,
                        child: FadeTransition(
                          opacity: _logoFade,
                          child: AnimatedBuilder(
                            animation: _pulseGlow,
                            builder: (context, child) {
                              return Container(
                                width: logoSize,
                                height: logoSize,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(
                                    logoSize * 0.24,
                                  ),
                                  border: Border.all(
                                    color: primaryTeal.withAlpha(150),
                                    width: 3,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: primaryTeal.withAlpha(
                                        (90 * _pulseGlow.value).toInt(),
                                      ),
                                      blurRadius: 30 * _pulseGlow.value,
                                      spreadRadius: 3,
                                    ),
                                    BoxShadow(
                                      color: Colors.black.withAlpha(80),
                                      blurRadius: 22,
                                      offset: const Offset(0, 10),
                                    ),
                                  ],
                                ),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(
                                    logoSize * 0.22,
                                  ),
                                  child: Image.asset(
                                    'assets/logo.jpeg',
                                    width: logoSize,
                                    height: logoSize,
                                    fit: BoxFit.cover,
                                    errorBuilder: (c, e, s) => Container(
                                      decoration: const BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [primaryTeal, accentCyan],
                                        ),
                                      ),
                                      alignment: Alignment.center,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.assured_workload_rounded,
                                            color: Colors.white,
                                            size: logoSize * 0.45,
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            'DZI',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: logoSize * 0.2,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 1.5,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),

                      const SizedBox(height: 30),

                      // Title & Badges
                      SlideTransition(
                        position: _textSlide,
                        child: FadeTransition(
                          opacity: _textFade,
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'DZI Infinity',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: titleSize,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: -0.5,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 9,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      gradient: const LinearGradient(
                                        colors: [primaryTeal, vibrantOrange],
                                      ),
                                      borderRadius: BorderRadius.circular(8),
                                      boxShadow: [
                                        BoxShadow(
                                          color: primaryTeal.withAlpha(100),
                                          blurRadius: 8,
                                        ),
                                      ],
                                    ),
                                    child: const Text(
                                      'PRO',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 0.8,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.white.withAlpha(22),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                    color: Colors.white.withAlpha(40),
                                  ),
                                ),
                                child: const Text(
                                  'E-Gov Services & Travel Desk Portal',
                                  style: TextStyle(
                                    color: Color(0xFF7DD3FC),
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.4,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Govt Portals • BBPS • Travels & Payments',
                                style: TextStyle(
                                  color: Colors.white.withAlpha(200),
                                  fontSize: 12,
                                  letterSpacing: 0.2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 44),

                      // Animated Progress Bar
                      FadeTransition(
                        opacity: _textFade,
                        child: Column(
                          children: [
                            AnimatedBuilder(
                              animation: _barWidth,
                              builder: (context, child) {
                                return Container(
                                  width: (screenWidth * 0.48).clamp(
                                    170.0,
                                    270.0,
                                  ),
                                  height: 4.5,
                                  decoration: BoxDecoration(
                                    color: Colors.white.withAlpha(30),
                                    borderRadius: BorderRadius.circular(3),
                                  ),
                                  alignment: Alignment.centerLeft,
                                  child: Container(
                                    width:
                                        ((screenWidth * 0.48).clamp(
                                          170.0,
                                          270.0,
                                        )) *
                                        _barWidth.value,
                                    height: 4.5,
                                    decoration: BoxDecoration(
                                      gradient: const LinearGradient(
                                        colors: [
                                          primaryTeal,
                                          accentCyan,
                                          vibrantOrange,
                                        ],
                                      ),
                                      borderRadius: BorderRadius.circular(3),
                                      boxShadow: [
                                        BoxShadow(
                                          color: primaryTeal.withAlpha(160),
                                          blurRadius: 8,
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),

                      const Spacer(flex: 3),

                      // Footer
                      FadeTransition(
                        opacity: _textFade,
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 16),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(
                                    Icons.verified_user_rounded,
                                    color: primaryTeal,
                                    size: 16,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    '100% Secure & Govt Authorized Portal',
                                    style: TextStyle(
                                      color: Colors.white.withAlpha(220),
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'Version 2.5.0 • DZI Infinity',
                                style: TextStyle(
                                  color: Colors.white.withAlpha(140),
                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}