import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../providers/auth_provider.dart';
import '../../services/api_service.dart';
import '../profile/profile_screen.dart';
import '../profile/my_applications_screen.dart';
import '../profile/help_support_screen.dart';
import '../services/service_detail_screen.dart';
import '../services/Home Product/Aadhaar/aadhaar_service_screen.dart';
import '../services/Home Product/Pan/pan_service_screen.dart';
import '../services/Home Product/Gst/gst_service_screen.dart';
import '../services/Home Product/Voter Id/voter_id_service_screen.dart';
import '../services/Home Product/Fastag/fastag_purchase_screen.dart';
import '../services/Home Product/Dsc/dsc_service_screen.dart';
import '../services/Home Product/Msme/msme_service_screen.dart';
import '../services/Home Product/Fssai/fssai_service_screen.dart';
import '../services/Home Product/Passport/passport_service_screen.dart';
import '../services/all_services_screen.dart';
import '../auth/login_screen.dart';
import '../notifications/notifications_screen.dart';
import '../career/career_screen.dart';
import '../services/BBPS Services/Landline/Landline.dart';
import '../services/BBPS Services/DTH/DTH.dart';
import '../services/BBPS Services/Electricity/Electricity.dart';
import '../services/BBPS Services/Piped Gas Bill/Piped Gas Bill.dart';
import '../services/BBPS Services/Gas Cylinder/Gas Cylinder.dart';
import '../services/BBPS Services/Recharge/recharge_screen.dart';
import '../services/BBPS Services/Water/Water.dart';
import '../services/BBPS Services/Education/Education.dart';
import '../services/BBPS Services/Loan Payment/Loan Payment.dart';
import '../services/BBPS Services/Housing Society/Housing Society.dart';
import '../services/BBPS Services/Fastag/Fastag.dart';
import '../services/BBPS Services/Metro Card/Metro Card.dart';
import '../services/BBPS Services/Broadband/Broadband.dart';
import '../services/BBPS Services/Insurance/Insurance.dart';
import '../services/Payment Services/Money Transfer/Money Transfer.dart';
import '../services/Travels/bus_booking_screen.dart';

class HomeScreen extends StatefulWidget {
  final bool isGuest;
  const HomeScreen({super.key, this.isGuest = false});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  int _selectedIndex = 0;
  List<Map<String, dynamic>> _allServices = [];
  int _notificationCount = 0;
  final ApiService _api = ApiService();

  late AnimationController _mainAnimationController;
  late AnimationController _pulseController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _pulseAnimation;
  late Animation<double> _scaleAnimation;

  final PageController _reviewController = PageController(
    viewportFraction: 0.88,
  );
  int _currentReview = 0;

  // Premium Teal + Orange Theme Palette (Money Transfer Reference)
  static const Color primaryTeal = Color(0xFF00A896);
  static const Color accentTeal = Color(0xFF028090);
  static const Color lightTealBg = Color(0xFFE0F2F1);
  static const Color primaryOrange = Color(0xFFFF6B00);
  static const Color deepOrange = Color(0xFFE65100);
  static const Color headerNavy = Color(0xFF00A896);
  static const Color headerNavyLight = Color(0xFF028090);
  static const Color bgCream = Color(0xFFF4FBF7);
  static const Color cardWhite = Color(0xFFFFFFFF);
  static const Color textDark = Color(0xFF0F172A);
  static const Color textMedium = Color(0xFF334155);
  static const Color textLight = Color(0xFF64748B);
  static const Color accentGold = Color(0xFFF59E0B);
  static const Color successGreen = Color(0xFF10B981);
  static const Color dangerRed = Color(0xFFEF4444);
  static const Color softOrange = Color(0xFFE0F2F1);

  // Additional vibrant accent colors
  static const Color indigoAccent = Color(0xFF4F46E5);
  static const Color purpleAccent = Color(0xFF8B5CF6);
  static const Color cyanAccent = Color(0xFF06B6D4);
  static const Color roseAccent = Color(0xFFF43F5E);

  List<Map<String, dynamic>> get _homeServices {
    final defaultOrder = [
      {
        'id': 'aadhaar',
        'name': 'Aadhaar Card',
        'category': 'E-Government',
        'icon': 'fingerprint',
        'color': '#D97706',
      },
      {
        'id': 'pan',
        'name': 'PAN Card',
        'category': 'E-Government',
        'icon': 'description',
        'color': '#2563EB',
      },
      {
        'id': 'gst',
        'name': 'GST Registration',
        'category': 'E-Government',
        'icon': 'receipt_long',
        'color': '#059669',
      },
      {
        'id': 'voter',
        'name': 'Voter ID',
        'category': 'E-Government',
        'icon': 'how_to_vote',
        'color': '#7C3AED',
      },
      {
        'id': 'fastag_purchase',
        'name': 'Fastag Purchase',
        'category': 'Home Product',
        'asset_image': 'assets/Fastag Purchase.png',
        'icon': 'directions_car',
        'color': '#00A896',
      },
      {
        'id': 'landline_bbps',
        'name': 'Landline',
        'category': 'BBPS Services',
        'asset_image': 'assets/Landline.jpg',
        'icon': 'phone_in_talk',
        'color': '#2563EB',
      },
    ];

    final result = <Map<String, dynamic>>[];
    for (final item in defaultOrder) {
      final nameKey = item['name'].toString().toLowerCase().split(' ').first;
      final match = _allServices.firstWhere(
        (s) => (s['name'] ?? '').toString().toLowerCase().contains(nameKey),
        orElse: () => item,
      );
      result.add(match);
    }
    return result;
  }

  @override
  void initState() {
    super.initState();

    final auth = Provider.of<AuthProvider>(context, listen: false);
    if (auth.services.isNotEmpty) {
      _allServices = List<Map<String, dynamic>>.from(auth.services);
    } else {
      _allServices = [
        {
          'id': 'pan',
          'name': 'PAN Card',
          'category': 'E-Government',
          'icon': 'description',
          'color': '#2563EB',
        },
        {
          'id': 'gst',
          'name': 'GST Registration',
          'category': 'E-Government',
          'icon': 'receipt_long',
          'color': '#059669',
        },
        {
          'id': 'voter',
          'name': 'Voter ID',
          'category': 'E-Government',
          'icon': 'how_to_vote',
          'color': '#7C3AED',
        },
        {
          'id': 'aadhaar',
          'name': 'Aadhaar Card',
          'category': 'E-Government',
          'icon': 'fingerprint',
          'color': '#D97706',
        },
        {
          'id': 'fastag_purchase',
          'name': 'Fastag Purchase',
          'category': 'Home Product',
          'asset_image': 'assets/Fastag Purchase.png',
          'icon': 'directions_car',
          'color': '#00A896',
        },
        {
          'id': 'landline_bbps',
          'name': 'Landline',
          'category': 'BBPS Services',
          'asset_image': 'assets/Landline.jpg',
          'icon': 'phone_in_talk',
          'color': '#2563EB',
        },
        {
          'id': 'payments',
          'name': 'Money Transfer',
          'category': 'Payment Services',
          'icon': 'payments',
          'color': '#16A34A',
        },
        {
          'id': 'recharge',
          'name': 'Mobile Recharge',
          'category': 'BBPS Services',
          'icon': 'phone_android',
          'color': '#059669',
        },
      ];
    }

    _mainAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    )..repeat(reverse: true);

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _mainAnimationController, curve: Curves.easeOut),
    );

    _pulseAnimation = Tween<double>(begin: 0.96, end: 1.04).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _scaleAnimation = Tween<double>(begin: 0.9, end: 1.0).animate(
      CurvedAnimation(
        parent: _mainAnimationController,
        curve: Curves.easeOutBack,
      ),
    );

    _mainAnimationController.forward();
    _startReviewAutoScroll();
    _loadData();
  }

  void _startReviewAutoScroll() {
    Future.delayed(const Duration(seconds: 5), () {
      if (mounted && _reviewController.hasClients) {
        _currentReview = (_currentReview + 1) % 6;
        _reviewController.animateToPage(
          _currentReview,
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeInOutCubic,
        );
        _startReviewAutoScroll();
      }
    });
  }

  @override
  void dispose() {
    _mainAnimationController.dispose();
    _pulseController.dispose();
    _reviewController.dispose();
    super.dispose();
  }

  String _normalizeCategory(String? cat) {
    if (cat == null) return 'E-Government';
    final s = cat.trim();
    final lower = s.toLowerCase();
    if (lower.contains('banking')) return 'Payment Services';
    if (lower.contains('business')) return 'E-Government';
    if (lower.contains('government') || lower.contains('goverment')) {
      return 'E-Government';
    }
    if (lower.contains('financial')) return ''; // Exclude Financial Services
    if (lower.contains('travel')) return 'Travels';
    return s;
  }

  Future<void> _loadData() async {
    final auth = Provider.of<AuthProvider>(context, listen: false);

    _api
        .getAnnouncementCount()
        .then((count) {
          if (mounted) setState(() => _notificationCount = count);
        })
        .catchError((_) {});

    await auth.loadServices();

    if (mounted) {
      setState(() {
        final seen = <String>{};
        _allServices = auth.services
            .map((s) {
              final item = Map<String, dynamic>.from(s);
              item['category'] = _normalizeCategory(
                item['category']?.toString(),
              );
              return item;
            })
            .where((s) {
              if ((s['category'] as String).isEmpty) return false;
              final name = (s['name'] ?? '').toString();
              if (seen.contains(name)) return false;
              seen.add(name);
              return true;
            })
            .toList();

        final hasRecharge = _allServices.any(
          (s) =>
              (s['name'] ?? '').toString().toLowerCase().contains('recharge'),
        );
        if (!hasRecharge) {
          _allServices.add({
            'id': 'recharge',
            'name': 'Mobile Recharge',
            'category': 'BBPS Services',
            'asset_image': 'assets/Postpaid Mobile Recharges.png',
            'icon': 'phone_android',
            'color': '#059669',
          });
        }

        final hasLandline = _allServices.any(
          (s) =>
              (s['name'] ?? '').toString().toLowerCase().contains('landline'),
        );
        if (!hasLandline) {
          _allServices.add({
            'id': 'landline_bbps',
            'name': 'Landline',
            'category': 'BBPS Services',
            'icon': 'phone_in_talk',
            'color': '#2563EB',
          });
        }

        final hasDth = _allServices.any(
          (s) => (s['name'] ?? '').toString().toLowerCase().contains('dth'),
        );
        if (!hasDth) {
          _allServices.add({
            'id': 'dth_bbps',
            'name': 'DTH Recharge',
            'category': 'BBPS Services',
            'icon': 'tv',
            'color': '#6D28D9',
          });
        }

        final hasElectricity = _allServices.any(
          (s) => (s['name'] ?? '').toString().toLowerCase().contains(
            'electricity',
          ),
        );
        if (!hasElectricity) {
          _allServices.add({
            'id': 'electricity_bbps',
            'name': 'Electricity Bill',
            'category': 'BBPS Services',
            'asset_image': 'assets/Electricity.png',
            'icon': 'bolt',
            'color': '#0284C7',
          });
        }

        final hasPipedGas = _allServices.any(
          (s) =>
              (s['name'] ?? '').toString().toLowerCase().contains('piped gas'),
        );
        if (!hasPipedGas) {
          _allServices.add({
            'id': 'piped_gas_bbps',
            'name': 'Piped Gas Bill',
            'category': 'BBPS Services',
            'asset_image': 'assets/Piped Gas Bill.jpg',
            'icon': 'propane_tank',
            'color': '#0EA5E9',
          });
        }

        final hasGasCylinder = _allServices.any(
          (s) =>
              (s['name'] ?? '').toString().toLowerCase().contains('cylinder'),
        );
        if (!hasGasCylinder) {
          _allServices.add({
            'id': 'gas_cylinder_bbps',
            'name': 'Gas Cylinder',
            'category': 'BBPS Services',
            'asset_image': 'assets/Gas.jpg',
            'icon': 'propane_tank',
            'color': '#E11D48',
          });
        }

        final hasHousing = _allServices.any(
          (s) =>
              (s['name'] ?? '').toString().toLowerCase().contains('housing') ||
              (s['name'] ?? '').toString().toLowerCase().contains('society'),
        );
        if (!hasHousing) {
          _allServices.add({
            'id': 'housing_society_bbps',
            'name': 'Housing Society',
            'category': 'BBPS Services',
            'asset_image': 'assets/Housing Society.png',
            'icon': 'home_work',
            'color': '#5A80F6',
          });
        }

        final hasFastagRecharge = _allServices.any(
          (s) =>
              (s['id'] == 'fastag_bbps') ||
              ((s['name'] ?? '').toString().toLowerCase().contains('fastag') &&
                  (s['category'] ?? '').toString().toLowerCase().contains('bbps')),
        );
        if (!hasFastagRecharge) {
          _allServices.add({
            'id': 'fastag_bbps',
            'name': 'FASTag Recharge',
            'category': 'BBPS Services',
            'asset_image': 'assets/Fastag.png',
            'icon': 'directions_car',
            'color': '#FF2D6C',
          });
        }

        final hasMetro = _allServices.any(
          (s) => (s['name'] ?? '').toString().toLowerCase().contains('metro'),
        );
        if (!hasMetro) {
          _allServices.add({
            'id': 'metro_card_bbps',
            'name': 'Metro Card Recharge',
            'category': 'BBPS Services',
            'asset_image': 'assets/Metro card Recharge.png',
            'icon': 'subway',
            'color': '#FF7D54',
          });
        }

        final hasBroadband = _allServices.any(
          (s) =>
              (s['name'] ?? '').toString().toLowerCase().contains('broadband'),
        );
        if (!hasBroadband) {
          _allServices.add({
            'id': 'broadband_bbps',
            'name': 'Broadband Bill',
            'category': 'BBPS Services',
            'asset_image': 'assets/Broadband.png',
            'icon': 'router',
            'color': '#6366F1',
          });
        }

        final hasInsurance = _allServices.any(
          (s) =>
              (s['name'] ?? '').toString().toLowerCase().contains('insurance'),
        );
        if (!hasInsurance) {
          _allServices.add({
            'id': 'insurance_bbps',
            'name': 'Insurance Premium',
            'category': 'BBPS Services',
            'asset_image': 'assets/Insurance premium.png',
            'icon': 'health_and_safety',
            'color': '#A855F7',
          });
        }

        final hasMoneyTransfer = _allServices.any(
          (s) =>
              (s['name'] ?? '').toString().toLowerCase().contains('money') ||
              (s['name'] ?? '').toString().toLowerCase().contains('transfer'),
        );
        if (!hasMoneyTransfer) {
          _allServices.add({
            'id': 'money_transfer_payment',
            'name': 'Money Transfer',
            'category': 'Payment Services',
            'asset_image': 'assets/Money Transfer.png',
            'icon': 'swap_horiz',
            'color': '#00A896',
          });
        }
      });
    }
  }

  Color _parseColor(dynamic c) {
    if (c == null) return primaryOrange;
    if (c is int) return Color(c);
    if (c is String) {
      String s = c.trim();
      if (s.startsWith('#')) s = '0xFF${s.substring(1)}';
      return Color(int.tryParse(s) ?? 0xFFFF6B00);
    }
    return primaryOrange;
  }

  IconData _parseIcon(dynamic i) {
    if (i == null) return Icons.assured_workload;
    if (i is IconData) return i;
    String iconStr = i.toString().trim();
    switch (iconStr) {
      case 'electricity':
      case 'bolt':
        return Icons.bolt_rounded;
      case 'dth':
      case 'tv':
        return Icons.tv_rounded;
      case 'landline':
      case 'phone_in_talk':
        return Icons.phone_in_talk;
      case 'account_balance':
        return Icons.account_balance;
      case 'payments':
        return Icons.payments;
      case 'phone_android':
        return Icons.phone_android;
      case 'flight_takeoff':
        return Icons.flight_takeoff;
      case 'health_and_safety':
        return Icons.health_and_safety;
      case 'credit_card':
        return Icons.credit_card;
      case 'receipt_long':
        return Icons.receipt_long;
      case 'description':
        return Icons.description;
      case 'fingerprint':
        return Icons.fingerprint;
      case 'account_balance_wallet':
        return Icons.account_balance_wallet;
      case 'point_of_sale':
        return Icons.point_of_sale;
      case 'receipt':
        return Icons.receipt;
      default:
        return Icons.assured_workload;
    }
  }

  String _imageUrl(String? relativePath) {
    if (relativePath == null || relativePath.trim().isEmpty) return '';
    String path = relativePath.trim();
    if (path.startsWith('http://') || path.startsWith('https://')) return path;
    final base = ApiService.baseUrl;
    if (base.endsWith('/api')) {
      final root = base.substring(0, base.length - 4);
      if (path.startsWith('/')) path = path.substring(1);
      return '$root/$path';
    } else {
      if (path.startsWith('/')) path = path.substring(1);
      return '$base/$path';
    }
  }

  // ==================== SERVICE TAP WITH POPUP ====================
  Future<void> _onServiceTap(Map<String, dynamic> service) async {
    final sId = (service['id'] ?? '').toString();
    final name = (service['name'] ?? '').toString().toLowerCase();

    if (sId == 'travel_irtc' || sId == 'travel_flight' || name.contains('irtc') || name.contains('flight booking')) {
      showComingSoonDialog(context);
      return;
    }

    if (sId == 'travel_bus' || name.contains('bus booking') || name.contains('bus ticket')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const BusBookingScreen()),
      );
      return;
    }

    final portalUrl = service['url']?.toString();
    if (portalUrl != null && portalUrl.trim().isNotEmpty) {
      final uri = Uri.parse(portalUrl.trim());
      try {
        final launched = await launchUrl(
          uri,
          mode: LaunchMode.externalApplication,
        );
        if (!launched) {
          await launchUrl(uri, mode: LaunchMode.platformDefault);
        }
      } catch (_) {
        try {
          await launchUrl(uri, mode: LaunchMode.platformDefault);
        } catch (_) {}
      }
      return;
    }

    final category = (service['category'] ?? '').toString().toLowerCase();

    if (name.contains('landline') || category.contains('landline')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const LandlineScreen()),
      );
      return;
    }

    if (name.contains('dth') || category.contains('dth')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const DTHScreen()),
      );
      return;
    }

    if (name.contains('electricity') || category.contains('electricity')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ElectricityScreen()),
      );
      return;
    }

    if (name.contains('piped gas') || category.contains('piped gas')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const PipedGasBillScreen()),
      );
      return;
    }

    if (name.contains('cylinder') ||
        category.contains('cylinder') ||
        name.contains('lpg')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const GasCylinderScreen()),
      );
      return;
    }

    if (name.contains('water') || category.contains('water')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const WaterScreen()),
      );
      return;
    }

    if (name.contains('education') ||
        name.contains('school') ||
        category.contains('education')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const EducationScreen()),
      );
      return;
    }

    if (name.contains('loan') ||
        name.contains('repayment') ||
        category.contains('loan')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const LoanPaymentScreen()),
      );
      return;
    }

    if (name.contains('fastag') ||
        name.contains('toll') ||
        category.contains('fastag')) {
      if (name.contains('purchase')) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => FastagPurchaseScreen(
              service: service,
              isGuest: widget.isGuest,
            ),
          ),
        );
      } else {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const FastagScreen()),
        );
      }
      return;
    }

    if (name.contains('metro') ||
        name.contains('subway') ||
        category.contains('metro')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const MetroCardScreen()),
      );
      return;
    }

    if (name.contains('broadband') ||
        name.contains('fiber') ||
        category.contains('broadband')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const BroadbandScreen()),
      );
      return;
    }

    if (name.contains('insurance') ||
        name.contains('policy') ||
        category.contains('insurance')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const InsuranceScreen()),
      );
      return;
    }

    if (name.contains('money') ||
        name.contains('dmt') ||
        name.contains('transfer') ||
        category.contains('payment')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const MoneyTransferScreen()),
      );
      return;
    }

    if (name.contains('housing') ||
        name.contains('society') ||
        category.contains('housing')) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const HousingSocietyScreen()),
      );
      return;
    }

    if ((name.contains('recharge') || category.contains('recharge')) &&
        !name.contains('fastag') &&
        !name.contains('dth') &&
        !name.contains('metro')) {
      _showRechargePopupDialog(service);
      return;
    }

    final rawId = service['id'];
    final intId = rawId is int ? rawId : int.tryParse(rawId?.toString() ?? '');

    List<Map<String, dynamic>> sections = [];

    if (intId != null) {
      try {
        final result = await _api
            .getServiceSections(intId)
            .timeout(const Duration(milliseconds: 1500));
        sections =
            (result['sections'] as List?)?.cast<Map<String, dynamic>>() ?? [];
      } catch (_) {}
    }

    if (sections.isEmpty) {
      final sName = (service['name'] ?? '').toString().toLowerCase();
      if (sName.contains('voter')) {
        sections = [
          {'id': 101, 'section_name': 'New Voter ID Application'},
          {'id': 102, 'section_name': 'Voter ID Correction / Update'},
          {'id': 103, 'section_name': 'Download E-Voter Card'},
        ];
      } else if (sName.contains('pan')) {
        sections = [
          {'id': 201, 'section_name': 'New PAN Card Application'},
          {'id': 202, 'section_name': 'Correction / Update PAN'},
          {'id': 203, 'section_name': 'Foreign PAN Application'},
        ];
      } else if (sName.contains('gst')) {
        sections = [
          {'id': 301, 'section_name': 'GST Registration'},
        ];
      } else if (sName.contains('aadhaar') || sName.contains('aadhar')) {
        sections = [
          {'id': 401, 'section_name': 'Soft Copy'},
          {'id': 402, 'section_name': 'Hard Copy'},
        ];
      } else if (sName.contains('aeps')) {
        sections = [
          {'id': 501, 'section_name': 'Cash Withdrawal'},
          {'id': 502, 'section_name': 'Balance Enquiry'},
          {'id': 503, 'section_name': 'Mini Statement'},
        ];
      }
    }

    if (!mounted) return;

    if (sections.length > 1) {
      _showSectionPopup(service, sections);
    } else {
      _openDetailScreen(
        service,
        sections.isNotEmpty ? Map<String, dynamic>.from(sections.first) : null,
      );
    }
  }

  void _openDetailScreen(
    Map<String, dynamic> service,
    Map<String, dynamic>? section,
  ) {
    final sName = (service['name'] ?? '').toString().toLowerCase();
    Widget targetScreen;

    if (sName.contains('aadhaar') || sName.contains('aadhar')) {
      targetScreen = AadhaarServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('pan')) {
      targetScreen = PanServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('gst')) {
      targetScreen = GstServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('voter')) {
      targetScreen = VoterIdServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('fastag')) {
      targetScreen = FastagPurchaseScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('dsc')) {
      targetScreen = DscServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('msme') || sName.contains('udyam')) {
      targetScreen = MsmeServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('fssai') || sName.contains('food')) {
      targetScreen = FssaiServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else if (sName.contains('passport')) {
      targetScreen = PassportServiceScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    } else {
      targetScreen = ServiceDetailScreen(
        service: service,
        isGuest: widget.isGuest,
        preselectedSectionId: section != null ? section['id'] as int? : null,
        preselectedSectionData: section,
      );
    }

    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, a, b) => targetScreen,
        transitionsBuilder: (_, animation, _, child) {
          return FadeTransition(
            opacity: animation,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.2, 0),
                end: Offset.zero,
              ).animate(
                CurvedAnimation(
                  parent: animation,
                  curve: Curves.easeOutCubic,
                ),
              ),
              child: ScaleTransition(
                scale: Tween<double>(begin: 0.9, end: 1.0).animate(animation),
                child: child,
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 350),
      ),
    );
  }

  void _showRechargePopupDialog(Map<String, dynamic> service) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withAlpha(150),
      builder: (ctx) {
        return Dialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 440),
            padding: const EdgeInsets.fromLTRB(16, 16, 12, 20),
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Mobile Recharge Services',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF0F172A),
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close_rounded, color: Color(0xFF64748B), size: 22),
                        onPressed: () => Navigator.pop(ctx),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Divider(height: 1, color: Color(0xFFE2E8F0)),
                  const SizedBox(height: 16),

                  InkWell(
                    onTap: () {
                      Navigator.pop(ctx);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const RechargeScreen(initialIsPostpaid: false),
                        ),
                      );
                    },
                    borderRadius: BorderRadius.circular(14),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFF00A896).withAlpha(50), width: 1.5),
                      ),
                      child: const Row(
                        children: [
                          CircleAvatar(
                            radius: 18,
                            backgroundColor: Color(0xFF00A896),
                            child: Icon(Icons.phone_android_rounded, color: Colors.white, size: 18),
                          ),
                          SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Prepaid Mobile Recharge',
                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5, color: Color(0xFF0F172A)),
                                ),
                                SizedBox(height: 2),
                                Text('Instant top-up for all prepaid plans', style: TextStyle(fontSize: 11, color: Color(0xFF64748B))),
                              ],
                            ),
                          ),
                          Icon(Icons.chevron_right_rounded, color: Color(0xFF00A896)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  InkWell(
                    onTap: () {
                      Navigator.pop(ctx);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const RechargeScreen(initialIsPostpaid: true),
                        ),
                      );
                    },
                    borderRadius: BorderRadius.circular(14),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFF0284C7).withAlpha(50), width: 1.5),
                      ),
                      child: const Row(
                        children: [
                          CircleAvatar(
                            radius: 18,
                            backgroundColor: Color(0xFF0284C7),
                            child: Icon(Icons.receipt_long_rounded, color: Colors.white, size: 18),
                          ),
                          SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Postpaid Mobile Recharges',
                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5, color: Color(0xFF0F172A)),
                                ),
                                SizedBox(height: 2),
                                Text('Pay monthly postpaid mobile bills', style: TextStyle(fontSize: 11, color: Color(0xFF64748B))),
                              ],
                            ),
                          ),
                          Icon(Icons.chevron_right_rounded, color: Color(0xFF0284C7)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showPassportPopupDialog(Map<String, dynamic> service) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withAlpha(150),
      builder: (ctx) {
        return Dialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 480),
            padding: const EdgeInsets.fromLTRB(20, 16, 16, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Service Details',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF333333),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close_rounded, color: Color(0xFF666666), size: 24),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                const Divider(height: 1, color: Color(0xFFE2E8F0)),
                const SizedBox(height: 20),

                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    // 1. GREEN BUTTON: NEW PASSPORT ▼
                    PopupMenuButton<int>(
                      offset: const Offset(0, 42),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      color: Colors.white,
                      elevation: 6,
                      onSelected: (int selectedId) {
                        Navigator.pop(ctx);
                        _openDetailScreen(service, {'id': selectedId});
                      },
                      itemBuilder: (context) => [
                        const PopupMenuItem(
                          value: 1,
                          child: Text('Normal (passport)', style: TextStyle(fontSize: 13, color: Color(0xFF333333))),
                        ),
                        const PopupMenuItem(
                          value: 2,
                          child: Text('Tatkal (passport)', style: TextStyle(fontSize: 13, color: Color(0xFF333333))),
                        ),
                        const PopupMenuItem(
                          value: 3,
                          child: Text('Minor Passport', style: TextStyle(fontSize: 13, color: Color(0xFF333333))),
                        ),
                      ],
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF0F9D58),
                          borderRadius: BorderRadius.circular(8),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF0F9D58).withAlpha(60),
                              blurRadius: 6,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'NEW PASSPORT',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12.5,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                              ),
                            ),
                            SizedBox(width: 4),
                            Icon(Icons.arrow_drop_down, color: Colors.white, size: 18),
                          ],
                        ),
                      ),
                    ),

                    // 2. ORANGE/YELLOW BUTTON: CORRECTION PASSPORT ▼
                    PopupMenuButton<int>(
                      offset: const Offset(0, 42),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      color: Colors.white,
                      elevation: 6,
                      onSelected: (int selectedId) {
                        Navigator.pop(ctx);
                        _openDetailScreen(service, {'id': selectedId});
                      },
                      itemBuilder: (context) => [
                        const PopupMenuItem(
                          value: 4,
                          child: Text('1st Correction / Renewal passport', style: TextStyle(fontSize: 13, color: Color(0xFF333333))),
                        ),
                        const PopupMenuItem(
                          value: 5,
                          child: Text('2nd Correction / Renewal tatkal passport', style: TextStyle(fontSize: 13, color: Color(0xFF333333))),
                        ),
                        const PopupMenuItem(
                          value: 6,
                          child: Text('3rd Lost / Damage passport', style: TextStyle(fontSize: 13, color: Color(0xFF333333))),
                        ),
                      ],
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE69719),
                          borderRadius: BorderRadius.circular(8),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFE69719).withAlpha(60),
                              blurRadius: 6,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'CORRECTION PASSPORT',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12.5,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                              ),
                            ),
                            SizedBox(width: 4),
                            Icon(Icons.arrow_drop_down, color: Colors.white, size: 18),
                          ],
                        ),
                      ),
                    ),

                    // 3. PCC BUTTON
                    InkWell(
                      onTap: () {
                        Navigator.pop(ctx);
                        _openDetailScreen(service, {'id': 7});
                      },
                      borderRadius: BorderRadius.circular(8),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF00A896),
                          borderRadius: BorderRadius.circular(8),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF00A896).withAlpha(60),
                              blurRadius: 6,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: const Text(
                          'PCC',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12.5,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showSectionPopup(Map<String, dynamic> service, List<dynamic> sections) {
    const tealPrimary = Color(0xFF00A896);
    const tealDark = Color(0xFF0284C7);

    List<dynamic> effectiveSections = List.from(sections);
    final serviceName = (service['name'] ?? '').toString().toLowerCase();
    if (serviceName.contains('passport')) {
      _showPassportPopupDialog(service);
      return;
    }

    if (serviceName.contains('pan')) {
      effectiveSections = [
        {'id': 202, 'section_name': 'Correction PAN'},
        {'id': 201, 'section_name': 'New PAN'},
        {'id': 203, 'section_name': 'Foreign PAN'},
        {'id': 204, 'section_name': 'Find PAN'},
      ];
    } else if (serviceName.contains('voter')) {
      effectiveSections = [
        {'id': 101, 'section_name': 'Voter ID'},
        {'id': 102, 'section_name': 'Correction Voter ID'},
        {'id': 103, 'section_name': 'Voter Print Hard Copy'},
        {'id': 104, 'section_name': 'Voter Print Soft Copy'},
      ];
    }

    showDialog(
      context: context,
      barrierColor: Colors.black.withAlpha(190),
      builder: (ctx) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 20),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 440),
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(28),
              boxShadow: [
                BoxShadow(
                  color: tealPrimary.withAlpha(60),
                  blurRadius: 30,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Top Header Banner with Teal Gradient
                Container(
                  padding: const EdgeInsets.fromLTRB(20, 20, 16, 20),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [tealPrimary, tealDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: Colors.white.withAlpha(45),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Icon(
                          _parseIcon(service['icon']),
                          color: Colors.white,
                          size: 26,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              (service['name'] ?? 'Service Option').toString(),
                              style: const TextStyle(
                                fontSize: 19,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 2),
                            const Text(
                              'Select an option to proceed',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.white70,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close_rounded, color: Colors.white, size: 22),
                        onPressed: () => Navigator.pop(ctx),
                      ),
                    ],
                  ),
                ),

                // List of Section Options with Modern Cards
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: effectiveSections.map((sec) {
                      final section = Map<String, dynamic>.from(sec);
                      final secName = (section['section_name'] ?? '').toString();
                      final isSoft = secName.toLowerCase().contains('soft');
                      final isHard = secName.toLowerCase().contains('hard');
                      final isFind = secName.toLowerCase().contains('find');
                      final isNew = secName.toLowerCase().contains('new');
                      final isForeign = secName.toLowerCase().contains('foreign');

                      IconData secIcon = Icons.credit_card_rounded;
                      String subtitle = 'Complete application details';
                      if (isSoft) {
                        secIcon = Icons.picture_as_pdf_rounded;
                        subtitle = 'Instant E-Aadhaar Digital Soft Copy';
                      } else if (isHard) {
                        secIcon = Icons.credit_card_rounded;
                        subtitle = 'Physical PVC Card Delivered to Address';
                      } else if (isFind) {
                        secIcon = Icons.search_rounded;
                        subtitle = 'Find existing PAN by Aadhaar number';
                      } else if (isNew) {
                        secIcon = Icons.add_card_rounded;
                        subtitle = 'Apply for new PAN card';
                      } else if (isForeign) {
                        secIcon = Icons.language_rounded;
                        subtitle = 'Apply for Foreign PAN card';
                      }

                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: () {
                              Navigator.pop(ctx);
                              _openDetailScreen(service, section);
                            },
                            borderRadius: BorderRadius.circular(16),
                            child: Container(
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: tealPrimary.withAlpha(50),
                                  width: 1.5,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withAlpha(8),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 42,
                                    height: 42,
                                    decoration: BoxDecoration(
                                      color: tealPrimary.withAlpha(20),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Icon(secIcon, color: tealPrimary, size: 22),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          secName,
                                          style: const TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xFF1E293B),
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          subtitle,
                                          style: const TextStyle(
                                            fontSize: 11,
                                            color: Color(0xFF64748B),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const Icon(
                                    Icons.arrow_forward_ios_rounded,
                                    size: 16,
                                    color: tealPrimary,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showLoginPage() {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, a, b) => const LoginScreen(),
        transitionsBuilder: (_, animation, _, child) {
          return FadeTransition(
            opacity: animation,
            child: ScaleTransition(
              scale: Tween<double>(begin: 0.95, end: 1.0).animate(
                CurvedAnimation(parent: animation, curve: Curves.easeOut),
              ),
              child: child,
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 300),
      ),
    ).then((_) => setState(() {}));
  }

  void _viewAllServices() {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, a, b) =>
            AllServicesScreen(services: _allServices, isGuest: widget.isGuest),
        transitionsBuilder: (_, animation, _, child) {
          return SlideTransition(
            position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
                .animate(
                  CurvedAnimation(
                    parent: animation,
                    curve: Curves.easeOutCubic,
                  ),
                ),
            child: FadeTransition(opacity: animation, child: child),
          );
        },
        transitionDuration: const Duration(milliseconds: 350),
      ),
    );
  }

  void _navigateWithAnimation(Widget screen) {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, a, b) => screen,
        transitionsBuilder: (_, animation, _, child) {
          return SlideTransition(
            position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
                .animate(
                  CurvedAnimation(
                    parent: animation,
                    curve: Curves.easeOutCubic,
                  ),
                ),
            child: FadeTransition(opacity: animation, child: child),
          );
        },
        transitionDuration: const Duration(milliseconds: 350),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final isGuest = !auth.isLoggedIn;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light,
      ),
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: bgCream,
        drawer: _buildDrawer(isGuest),
        body: RefreshIndicator(
          color: primaryOrange,
          backgroundColor: cardWhite,
          onRefresh: () async => _loadData(),
          child: ScaleTransition(
            scale: _scaleAnimation,
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildCurvedHeaderSection(isGuest),
                    Transform.translate(
                      offset: const Offset(0, -22),
                      child: Container(
                        width: double.infinity,
                        decoration: const BoxDecoration(
                          color: bgCream,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(26),
                            topRight: Radius.circular(26),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black12,
                              blurRadius: 16,
                              offset: Offset(0, -4),
                            ),
                          ],
                        ),
                        padding: const EdgeInsets.only(top: 24),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildSectionTitle(
                              'Our Premium Services',
                              onViewAll: _viewAllServices,
                            ),
                            const SizedBox(height: 16),
                            _buildServicesGrid(),
                            const SizedBox(height: 32),
                            _buildSectionTitle('Why Choose DZI Infinity'),
                            const SizedBox(height: 16),
                            _buildWhyChooseUs(),
                            const SizedBox(height: 32),
                            _buildStatsWithAnimation(),
                            const SizedBox(height: 32),
                            _buildTestimonialsCarousel(),
                            const SizedBox(height: 32),
                            _buildContactCTA(),
                            const SizedBox(height: 90),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        bottomNavigationBar: _buildBottomNav(),
      ),
    );
  }

  // ==================== CUSTOM CURVED HEADER SECTION (MATCHING SCREENSHOT) ====================
  Widget _buildCurvedHeaderSection(bool isGuest) {
    final auth = Provider.of<AuthProvider>(context);
    final name = isGuest ? 'Guest' : (auth.userName ?? 'User');

    return Container(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 38),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF00C9A7), Color(0xFF00A896), Color(0xFF028090)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top Action Row
            Row(
              children: [
                // 3-Line Menu Drawer Icon Button on LEFT
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withAlpha(20),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white.withAlpha(30)),
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.menu_rounded, size: 22),
                    color: Colors.white,
                    onPressed: () {
                      _scaffoldKey.currentState?.openDrawer();
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [primaryOrange, deepOrange],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: primaryOrange.withAlpha(90),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Text(
                      'DZI',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Text(
                          'DZI Infinity',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                            letterSpacing: 0.3,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [indigoAccent, purpleAccent],
                            ),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Text(
                            'PRO',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            color: isGuest ? textLight : successGreen,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: (isGuest ? textLight : successGreen)
                                    .withAlpha(140),
                                blurRadius: 6,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          isGuest ? 'Guest Mode' : 'Welcome, $name',
                          style: const TextStyle(
                            fontSize: 11,
                            color: Colors.white70,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const Spacer(),
                // Notification Icon on RIGHT
                Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withAlpha(20),
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white.withAlpha(30)),
                      ),
                      child: IconButton(
                        icon: const Icon(
                          Icons.notifications_outlined,
                          size: 22,
                        ),
                        color: Colors.white,
                        onPressed: () =>
                            _navigateWithAnimation(const NotificationsScreen()),
                      ),
                    ),
                    if (_notificationCount > 0)
                      Positioned(
                        right: 4,
                        top: 4,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: dangerRed,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: dangerRed.withAlpha(140),
                                blurRadius: 8,
                              ),
                            ],
                          ),
                          constraints: const BoxConstraints(
                            minWidth: 18,
                            minHeight: 18,
                          ),
                          child: Text(
                            '$_notificationCount',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ==================== SIDE NAVIGATION DRAWER ====================
  Widget _buildDrawer(bool isGuest) {
    final auth = Provider.of<AuthProvider>(context);
    final name = isGuest ? 'Guest User' : (auth.userName ?? 'User');
    final email = isGuest
        ? 'Tap login to access all services'
        : (auth.userEmail ?? '');

    return Drawer(
      backgroundColor: cardWhite,
      child: Column(
        children: [
          // Drawer Header
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 50, 20, 24),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [headerNavy, headerNavyLight],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [primaryOrange, deepOrange],
                        ),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: const Center(
                        child: Text(
                          'DZI',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'DZI Infinity',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Services & Banking Portal',
                          style: TextStyle(color: Colors.white70, fontSize: 11),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Text(
                  name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  email,
                  style: TextStyle(
                    color: Colors.white.withAlpha(180),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          // Drawer Menu List Items
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 10),
              children: [
                _drawerTile(
                  icon: Icons.home_rounded,
                  title: 'Home',
                  onTap: () => Navigator.pop(context),
                ),
                if (isGuest)
                  _drawerTile(
                    icon: Icons.login_rounded,
                    title: 'Login / Sign Up',
                    accentColor: primaryOrange,
                    onTap: () {
                      Navigator.pop(context);
                      _showLoginPage();
                    },
                  ),
                _drawerTile(
                  icon: Icons.receipt_long_rounded,
                  title: 'My Applications',
                  onTap: () {
                    Navigator.pop(context);
                    _navigateWithAnimation(const MyApplicationsScreen());
                  },
                ),
                _drawerTile(
                  icon: Icons.notifications_rounded,
                  title: 'Notifications',
                  onTap: () {
                    Navigator.pop(context);
                    _navigateWithAnimation(const NotificationsScreen());
                  },
                ),
                _drawerTile(
                  icon: Icons.person_rounded,
                  title: 'My Profile',
                  onTap: () {
                    Navigator.pop(context);
                    _navigateWithAnimation(const ProfileScreen());
                  },
                ),
                _drawerTile(
                  icon: Icons.work_rounded,
                  title: 'Career & Opportunities',
                  onTap: () {
                    Navigator.pop(context);
                    _navigateWithAnimation(const CareerScreen());
                  },
                ),
                const Divider(height: 20, indent: 16, endIndent: 16),
                _drawerTile(
                  icon: Icons.headset_mic_rounded,
                  title: '24/7 Customer Support',
                  onTap: () {
                    Navigator.pop(context);
                    _navigateWithAnimation(const HelpSupportScreen());
                  },
                ),
                if (!isGuest)
                  _drawerTile(
                    icon: Icons.logout_rounded,
                    title: 'Logout',
                    accentColor: dangerRed,
                    onTap: () {
                      Navigator.pop(context);
                      auth.logout();
                    },
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'Version 2.4.0 • DZI Infinity',
              style: TextStyle(color: textLight, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }

  Widget _drawerTile({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Color? accentColor,
  }) {
    return ListTile(
      leading: Icon(icon, color: accentColor ?? primaryOrange, size: 22),
      title: Text(
        title,
        style: TextStyle(
          color: accentColor ?? textDark,
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      ),
      onTap: onTap,
      horizontalTitleGap: 12,
    );
  }

  // ==================== SECTION TITLE ====================
  Widget _buildSectionTitle(String title, {VoidCallback? onViewAll}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Row(
              children: [
                Container(
                  width: 4.5,
                  height: 22,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [primaryOrange, deepOrange],
                    ),
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: textDark,
                      letterSpacing: 0.2,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (onViewAll != null) ...[
            const SizedBox(width: 8),
            InkWell(
              onTap: onViewAll,
              borderRadius: BorderRadius.circular(16),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: softOrange,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: primaryOrange.withAlpha(40)),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'View All',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: primaryOrange,
                      ),
                    ),
                    SizedBox(width: 4),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: 10,
                      color: primaryOrange,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ==================== SERVICES GRID ====================
  Widget _buildServicesGrid() {
    if (_homeServices.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Icon(Icons.inbox_outlined, size: 48, color: Colors.grey[300]),
              const SizedBox(height: 8),
              const Text(
                'No services available',
                style: TextStyle(color: textLight),
              ),
            ],
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          childAspectRatio: 0.80,
          crossAxisSpacing: 14,
          mainAxisSpacing: 14,
        ),
        itemCount: _homeServices.length,
        itemBuilder: (context, index) {
          final s = _homeServices[index];
          final String name = (s['name'] ?? '').toString();
          final Color color = _parseColor(s['color']);
          final IconData icon = _parseIcon(s['icon']);
          final String imageUrl = _imageUrl(s['image_url']?.toString());
          final lowerName = name.toLowerCase();
          final isEnlargedTarget =
              lowerName.contains('dth') ||
              lowerName.contains('electricity') ||
              lowerName.contains('piped') ||
              lowerName.contains('gas') ||
              lowerName.contains('water') ||
              lowerName.contains('education') ||
              lowerName.contains('loan') ||
              lowerName.contains('municipal') ||
              lowerName.contains('recharge') ||
              lowerName.contains('mobile') ||
              lowerName.contains('house') ||
              lowerName.contains('housing') ||
              lowerName.contains('fastag') ||
              lowerName.contains('metro') ||
              lowerName.contains('broad') ||
              lowerName.contains('insurance');
          final double logoSize = isEnlargedTarget ? 88.0 : 72.0;

          final assetImg = (s['asset_image'] ?? '').toString();
          String localAsset = assetImg;
          if (localAsset.isEmpty) {
            final lower = name.toLowerCase();
            if (lower.contains('landline')) localAsset = 'assets/Landline.jpg';
            if (lower.contains('dth')) localAsset = 'assets/DTH.png';
            if (lower.contains('electricity')) {
              localAsset = 'assets/Electricity.png';
            }
            if (lower.contains('piped gas')) {
              localAsset = 'assets/Piped Gas Bill.jpg';
            }
          }

          return GestureDetector(
            onTap: () => _onServiceTap(s),
            child: Container(
              decoration: BoxDecoration(
                color: cardWhite,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: color.withAlpha(40), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: color.withAlpha(20),
                    blurRadius: 14,
                    offset: const Offset(0, 5),
                  ),
                  BoxShadow(
                    color: Colors.black.withAlpha(6),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: logoSize,
                    height: logoSize,
                    child: Center(
                      child: _buildServiceLogoWidget(
                        name,
                        color,
                        icon,
                        localAsset,
                        imageUrl,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Text(
                      name,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: textDark,
                        height: 1.2,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildServiceLogoWidget(
    String name,
    Color color,
    IconData icon,
    String localAsset,
    String imageUrl,
  ) {
    final lower = name.toLowerCase();

    String assetPath = localAsset;
    if (!lower.contains('landline') && assetPath.contains('Landline.jpg')) {
      assetPath = '';
    }

    if (assetPath.isEmpty) {
      if (lower.contains('aadhaar')) assetPath = 'assets/Aadhaar.png';
      if (lower.contains('pan')) assetPath = 'assets/PAN.png';
      if (lower.contains('gst')) assetPath = 'assets/GST.png';
      if (lower.contains('voter')) assetPath = 'assets/Voter.png';
      if (lower.contains('fastag purchase') || lower.contains('fastag_purchase')) {
        assetPath = 'assets/Fastag Purchase.png';
      } else if (lower.contains('fastag') || lower.contains('toll')) {
        assetPath = 'assets/Fastag.png';
      }
      if (lower.contains('dsc')) assetPath = 'assets/DSC.png';
      if (lower.contains('msme') || lower.contains('udyam')) assetPath = 'assets/MSME.png';
      if (lower.contains('fssai') || lower.contains('food')) assetPath = 'assets/FSSAI.png';
      if (lower.contains('passport')) assetPath = 'assets/PassPort.png';
      if (lower.contains('metro')) {
        assetPath = 'assets/Metro card Recharge.png';
      }
      if (lower.contains('broadband') || lower.contains('fiber')) {
        assetPath = 'assets/Broadband.png';
      }
      if (lower.contains('insurance') || lower.contains('premium')) {
        assetPath = 'assets/Insurance premium.png';
      }
      if (lower.contains('money') || lower.contains('transfer')) {
        assetPath = 'assets/Money Transfer.png';
      }
      if (lower.contains('municipal') || lower.contains('tax')) {
        assetPath = 'assets/Muncipal Taxes.png';
      }
      if (lower.contains('recharge') ||
          lower.contains('postpaid') ||
          lower.contains('mobile')) {
        assetPath = 'assets/Postpaid Mobile Recharges.png';
      }
    }

    if (assetPath.isNotEmpty) {
      return Image.asset(
        assetPath,
        width: double.infinity,
        height: double.infinity,
        fit: BoxFit.contain,
        errorBuilder: (c, e, s) => _buildFallbackIconBadge(icon, color),
      );
    }

    if (imageUrl.isNotEmpty) {
      return Image.network(
        imageUrl,
        width: double.infinity,
        height: double.infinity,
        fit: BoxFit.contain,
        errorBuilder: (c, e, s2) => _buildFallbackIconBadge(icon, color),
        loadingBuilder: (c, child, progress) =>
            progress == null ? child : _buildFallbackIconBadge(icon, color),
      );
    }

    return _buildFallbackIconBadge(icon, color);
  }

  Widget _buildFallbackIconBadge(IconData icon, Color color) {
    return Icon(icon, color: color, size: 50);
  }

  // ==================== WHY CHOOSE US ====================
  Widget _buildWhyChooseUs() {
    final List<Map<String, dynamic>> items = [
      {
        'icon': Icons.rocket_launch_rounded,
        'title': 'Fast Processing',
        'tag': '⚡ FAST',
        'colors': [
          const Color.fromARGB(224, 92, 212, 102),
          const Color.fromARGB(255, 58, 120, 4),
        ],
        'desc': 'Quick turnaround in hours',
      },
      {
        'icon': Icons.verified_user_rounded,
        'title': '100% Secure',
        'tag': '🔒 SAFE',
        'colors': [
          const Color.fromARGB(255, 92, 120, 197),
          const Color(0xFF1D4ED8),
        ],
        'desc': 'Bank-grade encryption',
      },
      {
        'icon': Icons.headset_mic_rounded,
        'title': '24/7 Support',
        'tag': '🎧 LIVE',
        'colors': [
          const Color.fromARGB(255, 187, 104, 208),
          const Color.fromARGB(255, 109, 9, 180),
        ],
        'desc': 'Expert help anytime',
      },
      {
        'icon': Icons.stars_rounded,
        'title': 'Trusted Partner',
        'tag': '✨ GOVT',
        'colors': [
          const Color.fromARGB(255, 215, 111, 143),
          const Color(0xFFBE123C),
        ],
        'desc': 'Govt authorized portal',
      },
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.85,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
        ),
        itemCount: items.length,
        itemBuilder: (context, index) {
          final item = items[index];
          final List<Color> colors = item['colors'] as List<Color>;
          return GestureDetector(
            onTap: () {
              if (item['title'].toString().contains('Support')) {
                _navigateWithAnimation(const HelpSupportScreen());
              }
            },
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: colors,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                  color: Colors.white.withAlpha(50),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: colors[0].withAlpha(60),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: Colors.white.withAlpha(30),
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white.withAlpha(60)),
                        ),
                        child: Icon(
                          item['icon'] as IconData,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withAlpha(30),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          item['tag'] as String,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    item['title'] as String,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    item['desc'] as String,
                    style: TextStyle(
                      fontSize: 11,
                      color: Colors.white.withAlpha(210),
                      fontWeight: FontWeight.w500,
                      height: 1.2,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ==================== STATS CARDS ====================
  Widget _buildStatsWithAnimation() {
    final List<Map<String, dynamic>> stats = [
      {
        'v': '10K+',
        'l': 'Happy Customers',
        'tag': 'ACTIVE USERS',
        'i': Icons.people_alt_rounded,
        'color': primaryOrange,
      },
      {
        'v': '500+',
        'l': 'Service Centers',
        'tag': 'PAN INDIA',
        'i': Icons.storefront_rounded,
        'color': purpleAccent,
      },
      {
        'v': '24/7',
        'l': 'Live Support',
        'tag': 'ONLINE HELP',
        'i': Icons.support_agent_rounded,
        'color': cyanAccent,
      },
      {
        'v': '100%',
        'l': 'Verified Safe',
        'tag': 'ENCRYPTED',
        'i': Icons.shield_rounded,
        'color': successGreen,
      },
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.85,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
        ),
        itemCount: stats.length,
        itemBuilder: (context, index) {
          final s = stats[index];
          final Color color = s['color'] as Color;
          return ScaleTransition(
            scale: _pulseAnimation,
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: cardWhite,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: color.withAlpha(40), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: color.withAlpha(20),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: color.withAlpha(20),
                          shape: BoxShape.circle,
                          border: Border.all(color: color.withAlpha(40)),
                        ),
                        child: Icon(s['i'] as IconData, color: color, size: 18),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 7,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: color.withAlpha(15),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          s['tag'] as String,
                          style: TextStyle(
                            color: color,
                            fontSize: 8,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    s['v'] as String,
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      color: color,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    s['l'] as String,
                    style: const TextStyle(
                      fontSize: 11,
                      color: textDark,
                      fontWeight: FontWeight.w700,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ==================== REDESIGNED CUSTOMER REVIEWS SLIDER ====================
  Widget _buildTestimonialsCarousel() {
    final List<Map<String, dynamic>> list = [
      {
        'n': 'Deepa Agarwal',
        'role': 'Travel Enthusiast',
        'r':
            'Best service for PAN card application! Got it delivered super fast with no hassle. Highly recommended platform!',
        's': 5.0,
        'color': primaryOrange,
        'asset': 'assets/Deepa.png',
      },
      {
        'n': 'Priya Sharma',
        'role': 'Entrepreneur',
        'r':
            'GST registration completed in just 2 days. The customer support team guided me through every step patiently.',
        's': 5.0,
        'color': purpleAccent,
        'asset': 'assets/Priya.png',
      },
      {
        'n': 'Amit Patel',
        'role': 'Freelancer',
        'r':
            'Most reliable platform for all my business documentation and tax needs. Super transparent process.',
        's': 4.9,
        'color': indigoAccent,
        'asset': 'assets/Amit.png',
      },
      {
        'n': 'Sneha Mehta',
        'role': 'Retailer',
        'r':
            'Electricity and BBPS bill payments are seamless here. Instant receipts and great user interface!',
        's': 5.0,
        'color': roseAccent,
        'asset': 'assets/Sneha.png',
      },
      {
        'n': 'Vikram Rao',
        'role': 'Tax Consultant',
        'r':
            'ITR filing was effortless. Professional team with deep expertise. I recommend DZI Infinity to all my clients.',
        's': 5.0,
        'color': successGreen,
        'asset': 'assets/Vikram.png',
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle('Customer Reviews'),
        const SizedBox(height: 16),
        SizedBox(
          height: 200,
          child: PageView.builder(
            controller: _reviewController,
            itemCount: list.length,
            onPageChanged: (index) => setState(() => _currentReview = index),
            physics: const BouncingScrollPhysics(),
            itemBuilder: (context, index) {
              final t = list[index];
              final Color color = t['color'] as Color;
              final String assetPath = t['asset'] as String;

              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: cardWhite,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: color.withAlpha(40), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: color.withAlpha(20),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [color, color.withAlpha(120)],
                            ),
                          ),
                          child: CircleAvatar(
                            radius: 20,
                            backgroundColor: color,
                            child: ClipOval(
                              child: Image.asset(
                                assetPath,
                                width: 40,
                                height: 40,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) {
                                  return const Icon(
                                    Icons.account_circle_rounded,
                                    color: Colors.white,
                                    size: 26,
                                  );
                                },
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                t['n'] as String,
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w800,
                                  color: textDark,
                                ),
                              ),
                              Text(
                                t['role'] as String,
                                style: const TextStyle(
                                  fontSize: 11,
                                  color: textLight,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: accentGold.withAlpha(20),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: accentGold.withAlpha(40)),
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.star_rounded,
                                size: 14,
                                color: accentGold,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                t['s'].toString(),
                                style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 12,
                                  color: textDark,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Expanded(
                      child: Text(
                        '"${t['r']}"',
                        style: const TextStyle(
                          fontSize: 12,
                          color: textMedium,
                          fontStyle: FontStyle.italic,
                          height: 1.4,
                        ),
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(list.length, (index) {
            final isSelected = _currentReview == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: isSelected ? 20 : 6,
              height: 6,
              decoration: BoxDecoration(
                color: isSelected ? primaryOrange : primaryOrange.withAlpha(40),
                borderRadius: BorderRadius.circular(3),
              ),
            );
          }),
        ),
      ],
    );
  }

  // ==================== REDESIGNED CONTACT CTA WIDGET ====================
  Widget _buildContactCTA() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [
              Color(0xFF0F172A),
              Color.fromARGB(255, 42, 104, 205),
              Color(0xFF1E3A8A),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: primaryOrange.withAlpha(90), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF0F172A).withAlpha(60),
              blurRadius: 24,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [primaryOrange, deepOrange],
                ),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(color: primaryOrange.withAlpha(90), blurRadius: 16),
                ],
              ),
              child: const Icon(
                Icons.headset_mic_rounded,
                color: Colors.white,
                size: 32,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Need Assistance?',
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.3,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Our dedicated customer care team is online 24/7\nto assist you with any service queries.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white.withAlpha(220),
                fontSize: 13,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 20),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 10,
              runSpacing: 10,
              children: [
                _contactChip(
                  Icons.phone_in_talk_rounded,
                  'Call Us',
                  primaryOrange,
                ),
                _contactChip(
                  Icons.chat_bubble_rounded,
                  'Live Chat',
                  cyanAccent,
                ),
                _contactChip(Icons.email_rounded, 'Email Us', accentGold),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _contactChip(IconData icon, String label, Color accentColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(20),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: accentColor.withAlpha(100), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: accentColor.withAlpha(30),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: accentColor, size: 18),
          const SizedBox(width: 8),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  // ==================== FLOATING PILL BOTTOM NAV BAR ====================
  Widget _buildBottomNav() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: cardWhite,
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: primaryTeal.withAlpha(30), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: primaryTeal.withAlpha(45),
            blurRadius: 20,
            spreadRadius: 0,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: Colors.black.withAlpha(12),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _navItem(0, Icons.home_outlined, Icons.home_rounded, 'Home'),
            _navItem(
              1,
              Icons.assignment_outlined,
              Icons.assignment_rounded,
              'Requests',
            ),
            _navItem(
              2,
              Icons.grid_view_outlined,
              Icons.grid_view_rounded,
              'Services',
            ),
            _navItem(
              3,
              Icons.person_outline_rounded,
              Icons.person_rounded,
              'Profile',
            ),
          ],
        ),
      ),
    );
  }

  Widget _navItem(int index, IconData icon, IconData activeIcon, String label) {
    final isSelected = _selectedIndex == index;

    return InkWell(
      onTap: () {
        setState(() => _selectedIndex = index);
        if (index == 0) {
          // Home
        } else if (index == 1) {
          _navigateWithAnimation(const MyApplicationsScreen());
        } else if (index == 2) {
          _navigateWithAnimation(AllServicesScreen(services: _allServices));
        } else if (index == 3) {
          _navigateWithAnimation(const ProfileScreen());
        }
      },
      borderRadius: BorderRadius.circular(24),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutCubic,
        padding: EdgeInsets.symmetric(
          horizontal: isSelected ? 16 : 12,
          vertical: 9,
        ),
        decoration: BoxDecoration(
          gradient: isSelected
              ? const LinearGradient(
                  colors: [primaryTeal, accentTeal],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          borderRadius: BorderRadius.circular(24),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: primaryTeal.withAlpha(80),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isSelected ? activeIcon : icon,
              color: isSelected ? Colors.white : textLight,
              size: 22,
            ),
            if (isSelected) ...[
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ==================== CUSTOM CLIPPER FOR TOP CURVED HEADER (MATCHING SCREENSHOT) ====================
class HeaderCurveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(0, size.height - 65);
    final firstControlPoint = Offset(size.width * 0.28, size.height + 15);
    final firstEndPoint = Offset(size.width * 0.65, size.height - 35);
    path.quadraticBezierTo(
      firstControlPoint.dx,
      firstControlPoint.dy,
      firstEndPoint.dx,
      firstEndPoint.dy,
    );
    final secondControlPoint = Offset(size.width * 0.88, size.height - 75);
    final secondEndPoint = Offset(size.width, size.height - 25);
    path.quadraticBezierTo(
      secondControlPoint.dx,
      secondControlPoint.dy,
      secondEndPoint.dx,
      secondEndPoint.dy,
    );
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
